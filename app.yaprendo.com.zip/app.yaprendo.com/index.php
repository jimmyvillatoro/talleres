
<html lang="ES">
	
<head>
		
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />

<meta name="keywords" content="talleres, cursos, manuales, tutoriales, enseñanza, educación, aprender, educando," />

<meta name="description" content="un sitio para la educación" />

<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />




	<?php
	
include 'dat/cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado)>0)
{			  
      while ($row =mysqli_fetch_array($resultado)) 
	  {
	  $Dominio=$row[Dominio];


      }
}

mysqli_free_result($resultado);
mysqli_close($db_connection);
 ?>
				

<title><?php echo $Dominio; ?></title>

</head>

	
<body>


<div id="wrapper">
<div id="logo">
				


<h1><?php echo $Dominio; ?><span></span></h1>

<p>App</p>
			
</div>
</div>
	
			
<div id="page" class="round">
<div id="menu" class="round">
					
<ul>
						
<li><a href="sesion.php?Iddom=<?php echo $Iddom; ?>" title="" class="round active">Accede</a></a></li>
						
<li><a href="contacto.php?Iddom=<?php echo $Iddom; ?>" title="" class="round">Contacto</a></li>

</ul>	
				
</div>
	
	
		
				
<div id="splash">

<img src="dat/ima/curso.jpg" alt="" width="300" height="250" class="round" />


</div>

			
		
<div id="wrapper2" class="round">
						
<div id="sidebar" class="round">

<h3>Que es <?php echo $Dominio; ?>?</h3>
						
<ul>
						   
<li>La mejor plataforma de asesorias, cursos y talleres para aprendizaje  no formal bajo enfoques conductuales o cognitivos.</li>
						   
<li>Por medio de tecnología e-learning y multimedia  que se conecta de nuestros servidores al móvil, bajo la estructura referenciada </li> 
<img src="dat/ima/cate.jpg" width="300" height="200" class="round" />
<li>Tambien cuenta con CRM que Monitoriza a los alumnos para comprobar la adquisición, reforzamiento y modificación del proceso de aprendizaje y control de cada uno de ellos. asi como la expedición de certificados</li>
						   
<li>Tú tienes el talento, nosotros las herramientas.</li>
						   
<li><img src="dat/ima/taller.jpg" alt="" width="300" height="200" class="round" />
</li>
						
</ul>


						
<h3>¿Como funciona?</h3>
						
<ul>

<li>Con el uso de esta app, creas e impartes tu talento en línea, creando tus cursos, creando temas y subtemas, asignando contenidos de texto y referenciando medios como son: imagenes, audios, videos y archivos. Como nota importante en la cuestion de referencia no necesitas subir tu archivo a nuestros servidores, solo debes de tenerlos en algun servicio alterno ( youtube, googledrive, blogger ) y solo copiar el enlace a tu curso.</li>

<li>Luego publicas el enlace de tus cursos para inscripciones</li>

<li><img src="dat/ima/contacto.jpg" alt="" width="300" height="200" class="round" />
Cuando el alumno se registra, puedes darle seguimiento para comprobar la existencia de la modificabilidad cognitiva</li>
</ul>

<h3>¿Que debo de hacer?</h3>
<ul>
<li align="center">
Ponte en marcha con <?php echo $Dominio; ?> registrate como asesor. <a href="dat/php/ase/regasesor.php?tip=2&Iddom=<?php echo $Iddom; ?>"> <img src="dat/ima/clic.jpg" alt="" width="200" height="150"  class="round" /> </a></li>
</ul>

<h3>Nuestros Cursos Gatuitos</h3>
<ul>

<?php
include 'dat/cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$resultado1=mysqli_query($db_connection, "SELECT Curso FROM Cursos WHERE  Estado=1 ORDER BY Idcur  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Curso=$row1[Curso];
?> 
	<li><?php echo $Curso; ?> </a></li>
 
<?php
      }
}
mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>					
						   						   
<li><a href="dat/php/alu/registro.php?tip=1&Iddom=<?php echo $Iddom; ?>">  Regístrate para nuestros cursos.</a></li>

</ul>

<h3>Tú servicios en <?php echo $Dominio; ?></h3>
						
<ul>
			<img src="dat/ima/ctys.jpg" alt="" width="300" height="200"  class="round" />		   
<li>Los cursos pueden ser gratuitos o pagados</li>
						   
<li>Cada curso debe de tener como resultado un diploma</li>
						   
<li>El contenido debera ser apropiado y educativo</li>

<li>Que tú contenido ayude a la humanidad</li>

<li>Tú configuras tus propios enlaces de pago</li>

<li>Esta herramienta es gratuita</li>
						   
<li><a href="contacto.php?Iddom=<?php echo $Iddom; ?>  ">Contactanos</a></li>
						
</ul>



<h3>¿Cuánto voy a pagar?</h3>						
<ul>
<img src="dat/ima/exito.jpg" alt="" width="300" height="200"  class="round" />
<li>Su donación no es un pago, sino una SEMILLA sembrada para el apoyo de este proyecto de software web. Tenga en cuenta que NO estamos vendiendo esta aplicación, pero estamos dando estas versiones app Premium y Deluxe Completas como obsequios a nuestros generosos donantes.</li>
<li>Se requiere una cantidad mínima de donación para tener la Versión Premium y la Edición Completa Deluxe. Para más información por favor contáctenos.</li>
<li>Después de dar su donación, espere a que el Soporte técnico de prepare su código de activación dentro de las 24 horas. Recibirá un correo electrónico utilizando el correo electrónico que utilizó en PayPal con instrucciones sobre cómo activar.</li>
<li>Si no pudo recibir su código de activación, envíenos un correo electrónico utilizando su dirección de correo electrónico alternativa y confiable (Gmail).</li>
						   <li>La App para alumnos</li>
						   <li>La App para docentes</li>
						   <li>La App para administración</li>
						   <li>No pagas mensualidades</li>
<li>Solo recibimos donativos para desarrollo educativo</li>

     <div>
     <h4>Donar</h4>
     <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
     <input type="hidden" name="cmd" value="_s-xclick" />
     <input type="hidden" name="hosted_button_id" value="TSYBHXNLRV8NS" />
     <input type="image" src="https://www.paypalobjects.com/es_XC/MX/i/btn/btn_donateCC_LG.gif" border="0" name="submit" title="PayPal - ¡La forma más segura y fácil de donar en línea!" alt="Dona con el botón de PayPal" />
<img alt="" border="0" src="https://www.paypal.com/es_MX/i/scr/pixel.gif" width="1" height="1" />
     </form>
     </div>
</ul>

				
						
<h3>Nuestros Servicios </h3>
						
<ul>
		<img src="dat/ima/cursoz.jpg" alt="" width="300" height="200"  class="round" />		   
<li>Los cursos son gratuitos</li>
						   
<li>Cada curso tiene como resultado un diploma</li>
						   
<li>Puedes ser parte del equipo <a href="contacto.php?Iddom=<?php echo $Iddom; ?>">Contactanos</a></li>
						   
				
</ul>

	

					
<h3>Video</h3>
		
<ul>
  <li>Aprender</li>
<li>
						
<video src="https://d3c33hcgiwev3.cloudfront.net/vqySP1zYEeWq9g4QTIzkkQ.processed/full/360p/index.mp4?Expires=1595894400&Signature=dzp~kgWnVJj~Pw9WvVH2bbacUqkuMFj51EXauTF6JPl4E6bpl2ZtIqMdXFws2phVCAMiw0I5nAWzWQedrcb41HkBI-nZCbdq7GT4CCb4~J7t1qN6y8D7MS07YfGAS1MuI44kHC6VlwW3raijjnraNNkOeiZPg93Wz8LnQezaoaA_&Key-Pair-Id=APKAJLTNE6QMUY6HBC5A"  width="300" height="300" controls>
						
						
						
</li>
						
</ul>
	</div>
			
					
<!-- End Sidebar -->				
					
</div>
	
			
		
<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>

</body>



</html>
