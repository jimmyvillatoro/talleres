
<html lang="ES">
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<title>Contacto</title>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
		
<?php
	
include 'dat/cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado)>0)
{			  
      while ($row =mysqli_fetch_array($resultado)) 
	  {
	  $Dominio=$row[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado);
mysqli_close($db_connection);
 ?>
				
				<p>Contacto</p>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
					<ul>
<li><a href="index.php?Iddom=<?php echo $Iddom; ?>" title="" class="round active">Inicio</a></li>
<li><a href="soporte.php?Iddom=<?php echo $Iddom; ?> " title="" class="round">Soporte</a></li>
					</ul>	
				</div>
				
				<div id="splash">
<img src="dat/ima/user.jpg" alt="" width="300" height="200" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
				
						<h3>Contactanos</h3>
						<ul>
<li>Personal de Soporte</li>
 <li>soporte@yaprendo.com</li>
 
						</ul>
					
					<!-- End Sidebar -->				
					</div>
				
		<div id="footer">
			<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		</div>
		
		<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>

</body>


</html>
