<?php

include 'dat/cdb/db.php';
$cor = $_REQUEST['cor'];
$pas = $_REQUEST['pas'];
$Iddom = utf8_decode($_REQUEST['Iddom']);

$Tipo=0;

$resultado=mysqli_query($db_connection, "SELECT Idusu, Tipo FROM Usuarios  WHERE Correo = '".$cor."' && Pass= '".$pas."' ");

$cuenta=0;

while ($row =mysqli_fetch_array($resultado)) {
   	$Idusu=$row[Idusu];
	   $Tipo=$row[Tipo];
$cuenta++;
   }

if($cuenta==0)//salida
{
header('Location: index.php?Iddom='.$Iddom.'');

} else{

session_start(); 
$_SESSION['Idusu']=$Idusu;
     //sistema de administracion
	if($Tipo==3)
    header('Location: dat/php/adm/admin.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'');

 //sistema de asesores
	if($Tipo==2)
    header('Location: dat/php/ase/asesores.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'');

	//esta lleva a blog
	if($Tipo==1)
    header('Location: dat/php/alu/alumnos.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'');

  }	
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
