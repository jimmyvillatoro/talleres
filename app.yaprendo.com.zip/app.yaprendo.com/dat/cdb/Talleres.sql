-- phpMyAdmin SQL Dump
-- version 4.1.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 08:28 AM
-- Server version: 5.1.62
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Talleres`
--

-- --------------------------------------------------------

--
-- Table structure for table `Accesos`
--

CREATE TABLE IF NOT EXISTS `Accesos` (
  `Idacc` int(11) NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `Area` varchar(50) COLLATE ucs2_spanish_ci NOT NULL,
  `Idare` int(11) NOT NULL,
  `Idusu` int(11) NOT NULL,
  PRIMARY KEY (`Idacc`)
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Calificaciones`
--

CREATE TABLE IF NOT EXISTS `Calificaciones` (
  `Idcal` int(11) NOT NULL AUTO_INCREMENT,
  `Calificacion` float NOT NULL,
  `Descrip` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `Idcur` int(11) NOT NULL,
  `Idalu` int(11) NOT NULL,
  `Idase` int(11) NOT NULL,
  PRIMARY KEY (`Idcal`),
  KEY `Idcur` (`Idcur`,`Idalu`,`Idase`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Categorias`
--

CREATE TABLE IF NOT EXISTS `Categorias` (
  `Idcat` int(11) NOT NULL AUTO_INCREMENT,
  `Categoria` varchar(100) COLLATE ucs2_spanish_ci NOT NULL,
  `Descrip` text COLLATE ucs2_spanish_ci NOT NULL,
  `Orden` int(11) NOT NULL,
  `Estado` int(11) NOT NULL,
  `Iddom` int(11) NOT NULL,
  PRIMARY KEY (`Idcat`)
) ENGINE=MyISAM  DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `Categorias`
--

INSERT INTO `Categorias` (`Idcat`, `Categoria`, `Descrip`, `Orden`, `Estado`, `Iddom`) VALUES
(2, 'Biblica', 'Todo basado en la biblia', 1, 2, 1),
(1, 'Inducción', 'Todo basado en el uso de esta plataforma', 1, 1, 1),
(3, 'Diseño web', 'Todo basado en la web', 1, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Certificados`
--

CREATE TABLE IF NOT EXISTS `Certificados` (
  `Idcer` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(250) COLLATE ucs2_spanish_ci NOT NULL,
  `Slogan` varchar(250) COLLATE ucs2_spanish_ci NOT NULL,
  `Quehace` varchar(250) COLLATE ucs2_spanish_ci NOT NULL,
  `Quees` varchar(100) COLLATE ucs2_spanish_ci NOT NULL,
  `Porque` varchar(250) COLLATE ucs2_spanish_ci NOT NULL,
  `Curso` varchar(250) COLLATE ucs2_spanish_ci NOT NULL,
  `Aquien` int(250) NOT NULL,
  `Frase` varchar(250) COLLATE ucs2_spanish_ci NOT NULL,
  `Lugar` varchar(100) COLLATE ucs2_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idalu` int(11) NOT NULL,
  `Idase` int(11) NOT NULL,
  `Idadm` int(11) NOT NULL,
  PRIMARY KEY (`Idcer`)
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Controlescolar`
--

CREATE TABLE IF NOT EXISTS `Controlescolar` (
  `Idcon` int(11) NOT NULL AUTO_INCREMENT,
  `Aprobar` varchar(100) COLLATE ucs2_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `Idfin` int(11) NOT NULL,
  `Idcer` int(11) NOT NULL,
  PRIMARY KEY (`Idcon`),
  KEY `Idfin` (`Idfin`,`Idcer`)
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Cursos`
--

CREATE TABLE IF NOT EXISTS `Cursos` (
  `Idcur` int(11) NOT NULL AUTO_INCREMENT,
  `Curso` varchar(100) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `Descrip` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `Costo` float NOT NULL,
  `Promo` float NOT NULL,
  `Precio` float NOT NULL,
  `Estado` int(11) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Idcat` int(11) NOT NULL,
  `Idusu` int(11) NOT NULL,
  PRIMARY KEY (`Idcur`),
  KEY `Idusu` (`Idusu`)
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Dominios`
--

CREATE TABLE IF NOT EXISTS `Dominios` (
  `Iddom` int(11) NOT NULL AUTO_INCREMENT,
  `Dominio` varchar(50) COLLATE ucs2_spanish_ci NOT NULL,
  `Url` varchar(250) COLLATE ucs2_spanish_ci NOT NULL,
  `User` varchar(50) COLLATE ucs2_spanish_ci NOT NULL,
  `Pass` varchar(50) COLLATE ucs2_spanish_ci NOT NULL,
  `Db` varchar(50) COLLATE ucs2_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  PRIMARY KEY (`Iddom`)
) ENGINE=MyISAM  DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `Dominios`
--

INSERT INTO `Dominios` (`Iddom`, `Dominio`, `Url`, `User`, `Pass`, `Db`, `Estado`) VALUES
(1, 'El Taller', 'http://talleres.org', 'root', '', 'Talleres', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Finanzas`
--

CREATE TABLE IF NOT EXISTS `Finanzas` (
  `Idfin` int(11) NOT NULL AUTO_INCREMENT,
  `Monto` float NOT NULL,
  `Descu` float NOT NULL,
  `Descrip` varchar(250) COLLATE ucs2_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Idalu` int(11) NOT NULL,
  `Idcur` int(11) NOT NULL,
  `Idase` int(11) NOT NULL,
  `Idadm` int(11) NOT NULL,
  PRIMARY KEY (`Idfin`)
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Medios`
--

CREATE TABLE IF NOT EXISTS `Medios` (
  `Idmed` int(11) NOT NULL AUTO_INCREMENT,
  `Medio` varchar(100) COLLATE ucs2_spanish_ci NOT NULL,
  `Descrip` text COLLATE ucs2_spanish_ci NOT NULL,
  `Orden` int(11) NOT NULL,
  `Ruta` varchar(250) COLLATE ucs2_spanish_ci NOT NULL,
  `Url` text COLLATE ucs2_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Tabla` varchar(20) COLLATE ucs2_spanish_ci NOT NULL,
  `Idtab` int(11) NOT NULL,
  `Idcat` int(11) NOT NULL,
  PRIMARY KEY (`Idmed`)
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Subtemas`
--

CREATE TABLE IF NOT EXISTS `Subtemas` (
  `Idsub` int(11) NOT NULL AUTO_INCREMENT,
  `Subtema` varchar(100) COLLATE ucs2_spanish_ci NOT NULL,
  `Descrip` text COLLATE ucs2_spanish_ci NOT NULL,
  `Orden` int(11) NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idtem` int(11) NOT NULL,
  PRIMARY KEY (`Idsub`)
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Temas`
--

CREATE TABLE IF NOT EXISTS `Temas` (
  `Idtem` int(11) NOT NULL AUTO_INCREMENT,
  `Tema` varchar(100) COLLATE ucs2_spanish_ci NOT NULL,
  `Descrip` text COLLATE ucs2_spanish_ci NOT NULL,
  `Orden` int(11) NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idcur` int(11) NOT NULL,
  PRIMARY KEY (`Idtem`)
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Usuarios`
--

CREATE TABLE IF NOT EXISTS `Usuarios` (
  `Idusu` int(11) NOT NULL AUTO_INCREMENT,
  `Nombres` varchar(50) COLLATE ucs2_spanish_ci NOT NULL,
  `Apellidos` varchar(100) COLLATE ucs2_spanish_ci NOT NULL,
  `Correo` varchar(50) COLLATE ucs2_spanish_ci NOT NULL,
  `Movil` varchar(50) COLLATE ucs2_spanish_ci NOT NULL,
  `Pass` varchar(50) COLLATE ucs2_spanish_ci NOT NULL,
  `Mensaje` text COLLATE ucs2_spanish_ci NOT NULL,
  `Descrip` text COLLATE ucs2_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Idrus` int(11) NOT NULL,
  `Iddom` int(11) NOT NULL,
  PRIMARY KEY (`Idusu`),
  KEY `Idrus` (`Idrus`,`Iddom`)
) ENGINE=MyISAM  DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `Usuarios`
--

INSERT INTO `Usuarios` (`Idusu`, `Nombres`, `Apellidos`, `Correo`, `Movil`, `Pass`, `Mensaje`, `Descrip`, `Estado`, `Tipo`, `Idrus`, `Iddom`) VALUES
(1, 'Jimmy', 'Villatoro', 'jimmyvillatoro77@hotmail.com', '9613283039', '1234', 'Alunno', '', 1, 1, 0, 1),
(2, 'Jimmy', 'Villatoro', 'jimmyvillatoro77@gmail.com', '9613283039', '1234', 'Asesor', '', 1, 2, 0, 1),
(3, 'Jimmy', 'Villatoro', 'jimmyvillatoro77@yahoo.com', '9613283039', '1234', 'Administrador', '', 1, 3, 0, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
