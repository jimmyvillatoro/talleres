<?php

include '../../../cdb/db.php';

$Idusu = utf8_decode($_REQUEST['Idusu']);
$Iddom = utf8_decode($_REQUEST['Iddom']);
$Idcat = utf8_decode($_REQUEST['Idcat']);
$Idcur = utf8_decode($_REQUEST['Idcur']);
$Idtem = utf8_decode($_REQUEST['Idtem']);

$Idsub = $_REQUEST['Idsub'];

$sub =  $_REQUEST['sub'];
$des =  $_REQUEST['des'];
$ord =  $_REQUEST['ord'];


$update_value ="UPDATE Subtemas SET Subtema='".$sub."', Descrip='".$des."', Orden='".$ord."' WHERE Idsub='".$Idsub."' ";



	$retry_value = mysqli_query($db_connection,$update_value);


  if($retry_value)
         {
            header('Location: ctys.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'&Idsub='.$Idsub.'');
         }
         else
         {
            header('Location: updsubtema.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'');
         }




mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
