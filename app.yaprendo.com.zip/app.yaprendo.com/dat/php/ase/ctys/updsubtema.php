
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />



<?php


include '../../../cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);


$resultado0=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row0 =mysqli_fetch_array($resultado0)) {
   	 $nom=$row0[Nombres];
   }

mysqli_free_result($resultado0);
mysqli_close($db_connection);

?>


	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				
<?php
	
include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado1=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Dominio=$row1[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
			
<p>Actualiza el tema</p>

			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
					<ul>
						
<li><a href="ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>"  title="" class="round active">Atras</a></li>
						
<li><a href="../../../../soporte.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round">Soporte</a></li>

</ul>		
				</div>
				
				<div id="splash">
					<img src="../../../../dat/ima/tema.png" alt="" width="300" height="300" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
				<h3>Categoria</h3>

<ul>

<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$resultado2=mysqli_query($db_connection, "SELECT Categoria FROM Categorias WHERE  Iddom = '".$Iddom."' && Idcat = '".$Idcat."' && Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Categoria=$row2[Categoria];
   

?> 


	<li><a style="color:green;" ><?php echo $Categoria; ?> </a></li>
 

 
<?php

      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
	
				<h3>Curso</h3>

<ul>

<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$resultado3=mysqli_query($db_connection, "SELECT Curso FROM Cursos WHERE  Idcat = '".$Idcat."' && Estado=1 && Idusu = '".$Idusu."' && Idcur = '".$Idcur."' ORDER BY Idcur  ");

if (mysqli_num_rows($resultado3)>0)
{			  
      while ($row3 =mysqli_fetch_array($resultado3)) 
	  {
	  $Curso=$row3[Curso];
   

?> 


	<li><a style="color:green;" ><?php echo $Curso; ?> </a></li>
 

 
<?php

      }
}
mysqli_free_result($resultado3);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
			<h3>Temas</h3>
						
<ul>

				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$resultado4=mysqli_query($db_connection, "SELECT Tema, Descrip, Orden FROM Temas WHERE  Idtem = '".$Idtem."'  ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
	  
          $Tema=$row4[Tema];
         
          $Orden1=$row4[Orden];


?> 

 <li><a style="color:green;"
 ><?php echo $Orden1; ?>.-<?php echo $Tema; ?></a></li>

<?php

      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>
</li>

</ul>
				
				
			<h3>Subtemas</h3>
						
<ul>

				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);
$resultado5=mysqli_query($db_connection, "SELECT Subtema, Descrip, Orden FROM Subtemas WHERE  Idsub = '".$Idsub."'  ");

if (mysqli_num_rows($resultado5)>0)
{			  
      while ($row5 =mysqli_fetch_array($resultado5)) 
	  {
	  
          $Subtema=$row5[Subtema];
         $Descrip=$row5[Descrip];
         
          $Orden2=$row5[Orden];


?> 

 <li><a style="color:green;"
 ><?php echo $Orden2; ?>.-<?php echo $Subtema; ?></a></li>

<?php

      }
}
mysqli_free_result($resultado5);
mysqli_close($db_connection);
 ?>
</li>

</ul>
				

		
<h3>Actualiza el Subtema</h3>
<ul>
<li> 



<p>
<form action="pupdsubtema.php" method="POST">
            
<div>
                    <div>

  <input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>"> 
  <input type="hidden" name="Iddom" value="<?php echo utf8_decode($_GET['Iddom']); ?>">
  <input type="hidden" name="Idcat" value="<?php echo utf8_decode($_GET['Idcat']); ?>"> 
  <input type="hidden" name="Idcur" value="<?php echo utf8_decode($_GET['Idcur']); ?>">
  <input type="hidden" name="Idtem" value="<?php echo utf8_decode($_GET['Idtem']); ?>">
 <input type="hidden" name="Idsub" value="<?php echo utf8_decode($_GET['Idsub']); ?>">
 


 <input type="text" name="sub" class="form-control" class="form-input"
                           value="<?php echo $Subtema; ?>" required>
                    </div>
        
                        
                    
                </div>
                <div>
                    <div>
                        <textarea class="form-control" name="des" rows="10"  cols="28"  ><?php echo $Descrip; ?> </textarea>
                    </div>
                </div>
<div>
                    <div>
                        <input type="text" name="ord" class="form-control"  class="form-input"
                          value="<?php echo $Orden2; ?>"   required>
                    </div>
                </div>
         
                <div>
                    <div>
                        <button type="submit">Actualiza</button>
                                   </div>
                </div>
            </form>





</li>
						</ul>
					
					<!-- End Sidebar -->				
					</div>

				<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>	

		<div id="footer">
			<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		</div>
		
		
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	
</html>
