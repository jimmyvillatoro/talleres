<?php

include '../../../cdb/db.php';

$Idusu = utf8_decode($_REQUEST['Idusu']);
$Iddom = utf8_decode($_REQUEST['Iddom']);
$Idcat = utf8_decode($_REQUEST['Idcat']);
$Idcur = utf8_decode($_REQUEST['Idcur']);
$Idtem = utf8_decode($_REQUEST['Idtem']);
$Idsub = utf8_decode($_REQUEST['Idsub']);

$est = 0;



$update_value ="UPDATE Subtemas SET Estado='".$est."' WHERE Idsub='".$Idsub."' ";



	$retry_value = mysqli_query($db_connection,$update_value);

   if($retry_value)
         {
           header('Location: ctys.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'&Idsub='.$Idsub.'');
         }
         else
         {
            header('Location: delsubtema.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'');
         }





mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
