
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

<meta name="keywords" content="talleres, cursos, manuales, tutoriales, enseñanza, educación, aprender, educando," />
<meta name="description" content="un sitio para la educación" />
<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />
<title>Administra Tú Taller</title>
	
<?php


include '../../../cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }

mysqli_free_result($resultado);
mysqli_close($db_connection);

?>
</head>

	
	
<body>

	
	
<div id="wrapper">
<div id="logo">
				

<?php
	
include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado1=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Dominio=$row1[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
				
				
<p><a style="color:orange;"> Control Tema y Subtema </a></p>

</div>
	
		
			
<div id="page" class="round">
			
				
<div id="menu" class="round">
					
<ul>
						
<li><a href="../asesores.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round active">Atras</a></li>
						
<li><a href="../../../../soporte.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round">Soporte</a></li>

</ul>	
				
</div>
	
	
		
				
<div id="splash">
					
<img src="../../../../dat/ima/orga.jpg" alt="" width="300" height="200" class="round" />

</div>

			
		
<div id="wrapper2" class="round">
<div id="sidebar" class="round">

<h3>Categorias</h3>
						
					
<ul>
<li>Selecciona la Categoria</li>
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$resultado2=mysqli_query($db_connection, "SELECT Idcat, Categoria FROM Categorias WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Categoria=$row2[Categoria];
          $Idcatx=$row2[Idcat];

if(utf8_decode($_GET['Idcat']) == $Idcatx){
?> 


<li><a style="color:green;" href="ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcatx; ?>"><?php echo $Categoria; ?></a></li>
 
<?php
}else{

?> 


<li><a style="color:orange;" href="ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcatx; ?>"><?php echo $Categoria; ?></a></li>
 
<?php
}
      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
	
						
<h3>Cursos</h3>
						
					
<ul>
<li>Selecciona el Curso</li>
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$resultado3=mysqli_query($db_connection, "SELECT Idcur, Curso FROM Cursos WHERE  Idcat = '".$Idcat."' && Estado=1 && Idusu = '".$Idusu."' ORDER BY Idcur ");

if (mysqli_num_rows($resultado3)>0)
{			  
      while ($row3 =mysqli_fetch_array($resultado3)) 
	  {
	  $Curso=$row3[Curso];
          $Idcurx=$row3[Idcur];


if(utf8_decode($_GET['Idcur']) == $Idcurx){
?> 

<li><a  style="color:green;" href="ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>"><?php echo $Curso; ?></a></li>
 	<?php
}else{

?> 
 
<li><a  style="color:orange;" href="ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>"><?php echo $Curso; ?></a></li>

<?php
}
      }
}
mysqli_free_result($resultado3);
mysqli_close($db_connection);
 ?>
</li>					
</ul>

				
<h3>Temas</h3>
						
<ul>
<li>Seleccionar el temas <a href="regtema.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>">Agrega</a>


				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$resultado4=mysqli_query($db_connection, "SELECT Idtem, Tema FROM Temas WHERE  Idcur = '".$Idcur."' && Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
	  $Tema=$row4[Tema];
          $Idtemx=$row4[Idtem];



if(utf8_decode($_GET['Idtem']) == $Idtemx){
?> 

<li>
<a  style="color:green;" href="ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>"><?php echo $Tema; ?></a>

<a href="deltema.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtemx; ?>">Quita</a>

<a href="updtema.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtemx; ?>">Actualiza</a></li>


 	<?php
}else{

?> 
 <li>

<a  style="color:orange;" href="ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtemx; ?>"><?php echo $Tema; ?>

<a href="deltema.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtemx; ?>">Quita</a>

<a href="updtema.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtemx; ?>">Actualiza</a></li>

<?php
}
      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>
</li>

</ul>
				
<h3>Subtemas</h3>
						
<ul>
<li>Seleccionar el subtemas <a href="regsubtema.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>">Agrega</a>


				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);
$resultado5=mysqli_query($db_connection, "SELECT Idsub, Subtema FROM Subtemas WHERE  Idtem = '".$Idtem."' && Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($resultado5)>0)
{			  
      while ($row5 =mysqli_fetch_array($resultado5)) 
	  {

	$Subtema=$row5[Subtema];
 $Idsubx=$row5[Idsub];



if(utf8_decode($_GET['Idsub']) == $Idsubx){
?> 

<li><a  style="color:green;" href="ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?>"><?php echo $Subtema; ?></a>

<a href="delsubtema.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?> ">Quita</a>

<a href="updsubtema.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?>">Actualiza</a>

</li>


 	<?php
}else{

?> 

<li><a  style="color:orange;" href="ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?>"><?php echo $Subtema; ?></a>

<a href="delsubtema.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?> ">Quita</a>

<a href="updsubtema.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?>">Actualiza</a></li>


<?php
}
      }
}
mysqli_free_result($resultado5);
mysqli_close($db_connection);
 ?>
</li>

</ul>
				
							
						
<h3>Información</h3>
						
<ul>
<li>En esta área creas los temas y subtemas del curso seleccionado</li>
<li>Crea tu curso a la medida de tú capacidad</li>
<li>Comunicate con nosotros.</li>
</ul>

						

					
<!-- End Sidebar -->				
					
</div>
	
<p><a style="color:orange;"> <?php echo $nom; ?> </a></p>
		
<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

</html>
