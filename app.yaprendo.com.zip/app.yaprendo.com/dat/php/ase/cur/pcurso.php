<?php

include '../../../cdb/db.php';

$Iddom = utf8_decode($_REQUEST['Iddom']);
$cur = $_REQUEST['cur'];
$des = $_REQUEST['des'];
$tip = $_REQUEST['tip'];
$pre = $_REQUEST['pre'];
$cos = $_REQUEST['cos'];
$pro = $_REQUEST['pro'];
$est = 1;
$Idcat = utf8_decode($_REQUEST['selCombo1']);
$Idusu= utf8_decode($_REQUEST['Idusu']);

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$resultado=mysqli_query($db_connection, "SELECT Idcur FROM Cursos WHERE Curso = '".$cur."' ");
 

if (mysqli_num_rows($resultado)>0)
	{
header('Location: selcurso.html?Idusu='.$Idusu.'&Iddom='.$Iddom.'&cur='.$cur.'');
}
  else {


$insert_value ="INSERT INTO Cursos (Curso, Descrip, Precio, Costo, Promo, Estado, Tipo, Idcat, Idusu) VALUES ( '".$cur."' ,  '".$des."', '".$pre."', '".$cos."', '".$pro."',  '".$est."', '".$tip."', '".$Idcat."', '".$Idusu."'  )";

	$retry_value = mysqli_query($db_connection,$insert_value);



header('Location: ../asesores.php?Idusu='.$Idusu.'&Iddom='.$Iddom.' ');

}

mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
