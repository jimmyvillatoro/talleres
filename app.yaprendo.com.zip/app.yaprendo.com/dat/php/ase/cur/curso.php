
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

<meta name="keywords" content="talleres, cursos, manuales, tutoriales, enseñanza, educación, aprender, educando," />
<meta name="description" content="un sitio para la educación" />
<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta charset="UTF-8">	

<title>Los Talleres Educativos</title>
	
<?php


include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);


$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }

mysqli_free_result($resultado);
mysqli_close($db_connection);

?>


</head>

	
	
<body>

	
	
<div id="wrapper">
<div id="logo">
				

<?php
	
include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado1=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Dominio=$row1[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
				
				
<p>Curso</p>
							

	</div>
	
		
			
<div id="page" class="round">
			
				
<div id="menu" class="round">
					
<ul>
						
<li><a href="../asesores.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round active">Atrás</a></li>

<li><a href="../../../../soporte.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round ">Soporte</a></li>
						


</ul>	
				
</div>
	
	
		
				
<div id="splash">
					
<img src="../../../ima/exito.jpg" alt="" width="300" height="200" class="round" />

</div>

			
		
<div id="wrapper2" class="round">
						
<div id="sidebar" class="round">
					
<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>

						
						


<h3>Categorias</h3>
						
					
<ul>
<li>Selecciona la Categoria</li>
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$resultado2=mysqli_query($db_connection, "SELECT Idcat, Categoria FROM Categorias WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Categoria=$row2[Categoria];
          $Idcatx=$row2[Idcat];

if(utf8_decode($_GET['Idcat']) == $Idcatx){
?> 


	<li>

<a style="color:green;" href="curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcatx; ?>"><?php echo $Categoria; ?></a>




</li>
 
<?php
}else{

?> 


	<li><a style="color:orange;" href="curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcatx; ?>"><?php echo $Categoria; ?></a></li>
 
<?php
}
      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
	

						
<h3>Control de cursos</h3>
						

						
<ul>
<li>Seleccionar el curso <a href="regcurso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>">Agrega</a>
</li>
				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);


$resultado4=mysqli_query($db_connection, "SELECT Idcur, Curso FROM Cursos WHERE  Idcat = '".$Idcat."' &&  Idusu = '".$Idusu."' && Estado=1 ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
	  $Curso=$row4[Curso];
          $Idcurx=$row4[Idcur];



if(utf8_decode($_GET['Idcur']) == $Idcurx){
?> 

<li><a  style="color:green;" href="curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>"><?php echo $Curso; ?></a>

<a href="delcurso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>">Quita</a>

<a href="updcurso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>">Actualiza</a>

<a href="../vercurso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>">Ver</a>

</li>


 	<?php
}else{

?> 
 <li><a  style="color:orange;" href="curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>"><?php echo $Curso; ?>

<a href="delcurso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>">Quita</a>

<a href="updcurso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>">Actualiza</a>

<a href="../vercurso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>">Ver</a>

</li>

<?php
}
      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>
</li>

</ul>
					
					
<!-- End Sidebar -->				
					
</div>
	
			
		
<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>



</html>
