
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />



<?php


include '../../../cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);



$resultado0=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row0 =mysqli_fetch_array($resultado0)) {
   	 $nom=$row0[Nombres];
   }

mysqli_free_result($resultado0);
mysqli_close($db_connection);

?>


	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				
<?php
	
include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado1=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Dominio=$row1[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
			
<p>Actualiza el curso</p>

			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
					<ul>
						
<li><a href="curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>"  title="" class="round active">Atras</a></li>
						
<li><a href="../../../../soporte.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round">Soporte</a></li>

</ul>		
				</div>
				
				<div id="splash">
					<img src="../../../../dat/ima/titul.png" alt="" width="300" height="300" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
				
						<h3>Actualiza el Curso</h3>
						<ul>
<li> 

	<h3>Categoria</h3>

<ul>

<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$resultado2=mysqli_query($db_connection, "SELECT Idcat, Categoria FROM Categorias WHERE  Iddom = '".$Iddom."' && Idcat = '".$Idcat."' && Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Categoria=$row2[Categoria];
   $Idcat=$row2[Idcat];

?> 


	<li><a style="color:green;" ><?php echo $Categoria; ?> </a></li>
 

 
<?php

      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
	
				<h3>Curso</h3>

<ul>

<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$resultado2=mysqli_query($db_connection, "SELECT Curso, Descrip, Costo, Promo, Precio, Tipo FROM Cursos WHERE  Idcat = '".$Idcat."' && Estado=1 && Idusu = '".$Idusu."' && Idcur = '".$Idcur."' ORDER BY Idcur  ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Curso=$row2[Curso];
   $Descrip=$row2[Descrip];

$Costo=$row2[Costo];
$Promo=$row2[Promo];
$Precio=$row2[Precio];
$Tipo=$row2[Tipo];
?> 


	<li><a style="color:green;" ><?php echo $Curso; ?> </a></li>
 

 
<?php

      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>

						

<p>
<form action="pupdcurso.php" method="POST">
            
<div>
                    <div>

  <input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>"> 
  <input type="hidden" name="Iddom" value="<?php echo utf8_decode($_GET['Iddom']); ?>">
  <input type="hidden" name="Idcat" value="<?php echo utf8_decode($_GET['Idcat']); ?>"> 
  <input type="hidden" name="Idcur" value="<?php echo utf8_decode($_GET['Idcur']); ?>">
 
 


<input type="text" name="cur" class="form-control" class="form-input"
      value="<?php echo $Curso; ?>" required>
                    </div>
        
                        
                    
                </div>
                <div>
                    <div>
                        <textarea class="form-control" name="des" rows="10"  cols="28"  ><?php echo $Descrip; ?> </textarea>
                    </div>
                </div>

 <div>                 
 <input type="text" name="tip" class="form-control" placeholder="Tipo = 1 gratis 2 pagado " class="form-input"   value="<?php echo $Tipo; ?>"                        required>    
      </div>  
         
 <div>                 
 <input type="text" name="cos" class="form-control" placeholder="Costo" class="form-input"    value="<?php echo $Costo; ?>"                       required>    
      </div>  
         
 <div>                 
 <input type="text" name="pre" class="form-control" placeholder="Precio" class="form-input"     value="<?php echo $Precio; ?>"                      required>    
      </div>  
         

 <div>                 
 <input type="text" name="pro" class="form-control" placeholder="Promoción" class="form-input"    value="<?php echo $Promo; ?>"                       required>    
      </div>  

                <div>
                    <div>
                        <button type="submit">Actualiza</button>
                                   </div>
                </div>
            </form>





</li>
						</ul>
					
					
					<!-- End Sidebar -->				
					</div>

				<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>	

		<div id="footer">
			<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		</div>
		
		
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	
</html>
