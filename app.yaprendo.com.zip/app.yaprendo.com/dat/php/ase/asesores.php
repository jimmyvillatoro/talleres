
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />


<meta name="keywords" content="talleres, cursos, manuales, tutoriales, enseñanza, educación, aprender, educando," />
<meta name="description" content="un sitio para la educación" />

<link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />


<title>Administrando</title>
	
<?php
include '../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

</head>

<body>

<div id="wrapper">
<div id="logo">

<?php
include '../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$resultado=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado)>0)
{			  
      while ($row =mysqli_fetch_array($resultado)) 
	  {
	  $Dominio=$row[Dominio];
?> 
<h1><?php echo $Dominio; ?><span></span></h1>
<?php
      }
}
mysqli_free_result($resultado);
mysqli_close($db_connection);
 ?>
	
<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>
			
</div>
	
		
<div id="page" class="round">
<div id="menu" class="round">		
<ul>	
				
<li><a href="../../../index.php?Iddom=<?php echo $Iddom; ?>" title="" class="round active">Inició</a></li>	
			
<li><a href="../../../soporte.php?Iddom=<?php echo $Iddom; ?>" title="" class="round">Soporte</a></li>
</ul>	
				
</div>			
<div id="splash">			
<img src="../../ima/splash.jpg" alt="" width="300" height="200" class="round" />
</div>
	
<div id="wrapper2" class="round">					
<div id="sidebar" class="round">					
<h3>Tu Lista de Cursos</h3>					
<ul>
<?php
include '../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$resultado1=mysqli_query($db_connection, "SELECT Idcur, Curso FROM Cursos WHERE  Idusu = '".$Idusu."' && Estado=1 ORDER BY Idcur  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Curso=$row1[Curso];
	  $Idcurx=$row1[Idcur];
?> 
	<li><a href="repcurso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcur=<?php echo $Idcurx; ?>"> <img src="../../ima/pdf.png" alt="" width="50" height="40"  class="round"/> <?php echo $Curso; ?> </a></li>
 
<?php
      }
}
mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>					
</ul>


<h3>Control de Cursos</h3>					
<ul>		

<li align="center">
<a href="cur/curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> <img src="../../ima/curso.jpg" alt="" width="200" height="150"  class="round" /> </a></li>
<li align="center">
<a href="cur/curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">Administrar mis cursos</a></li>		
</ul>

<h3>Control de contenido</h3>
<ul>	

<li align="center">
<a href="ctys/ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> <img src="../../ima/orga.jpg" alt="" width="200" height="150"  class="round" /> </a></li>


<li align="center">
<a href="ctys/ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">Administrar el contenido</a></li>
</ul>
	
<h3>Control de Medios</h3>					
<ul>

<li align="center">
<a href="med/medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> <img src="../../ima/medios.jpg" alt="" width="200" height="150"  class="round" /> </a></li>


<li align="center"><a href="med/medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">Administrar los medios</a></li>					
</ul>


<h3>Control de Alumnos</h3>					
<ul>
<li align="center">
<a href="alu/alum.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> <img src="../../ima/users.png" alt="" width="200" height="150"  class="round" /> </a></li>

<li align="center"><a href="alu/alum.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">Administrar los alumnos</a></li>					
</ul>


<h3>Control de tu perfil</h3>					
<ul>
<li align="center">
<a href="perfil.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> <img src="../../ima/user.jpeg" alt="" width="200" height="150"  class="round" /> </a></li>
<li align="center"><a href="perfil.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">Administrar tu perfil</a></li>					
</ul>

<h3>Información</h3>
						
<ul>
 
<li>Los datos están seguros en la nube, pero puedes tener instalada nuestra plataforma en tu sitio web.</li>
						<img src="../../ima/datos.jpg" alt="" width="300" height="200" class="round" />     
<li>Nosotros hicimos está plataforma pensando en un bien común para la humanidad.</li>
						
</ul>


					
					
<!-- End Sidebar -->				
					
</div>
	
			
		
<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

</html>
