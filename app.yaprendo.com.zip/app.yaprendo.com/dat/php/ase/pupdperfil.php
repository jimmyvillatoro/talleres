<?php

include '../../cdb/db.php';

$Idusu = utf8_decode($_REQUEST['Idusu']);
$Iddom = utf8_decode($_REQUEST['Iddom']);

$nom = $_REQUEST['nom'];
$ape = $_REQUEST['ape'];
$cor = $_REQUEST['cor'];
$mov = $_REQUEST['mov'];
$des = $_REQUEST['des'];



$update_value ="UPDATE Usuarios SET Nombres='".$nom."', Apellidos='".$ape."', Correo='".$cor."', Movil='".$mov."', Descrip='".$des."' WHERE Idusu='".$Idusu."' ";



	$retry_value = mysqli_query($db_connection,$update_value);



header('Location: perfil.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'');



mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
