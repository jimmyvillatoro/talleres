<?php

include '../../../cdb/db.php';


$Idusu = utf8_decode($_REQUEST['Idusu']);
$Iddom = utf8_decode($_REQUEST['Iddom']);
$Tabla = $_REQUEST['Tabla'];
$Idtab = utf8_decode($_REQUEST['Idtab']);
$Idcat = utf8_decode($_REQUEST['Idcat']);
$Idcur = utf8_decode($_REQUEST['Idcur']);
$Idtem = utf8_decode($_REQUEST['Idtem']);
$Idsub = utf8_decode($_REQUEST['Idsub']);


$med = $_REQUEST['med'];
$des = $_REQUEST['des'];
$url = $_REQUEST['url']; 
$ord = $_REQUEST['ord'];

$est = 1;


date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());



$insert_value ="INSERT INTO Medios (Medio, Descrip, Url, Estado, Orden,  Idcat, Tabla, Idtab) VALUES ( '".$med."' ,  '".$des."',  '".$url."', '".$est."', '".$ord."',  '".$Idcat."', '".$Tabla."', '".$Idtab."' )";

	$retry_value = mysqli_query($db_connection,$insert_value);


header('Location: medios.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'&Idsub='.$Idsub.' ');



mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
