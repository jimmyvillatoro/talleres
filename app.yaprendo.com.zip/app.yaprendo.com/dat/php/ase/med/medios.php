
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

		

<meta name="keywords" content="talleres, cursos, manuales, tutoriales, enseñanza, educación, aprender, educando," />
		

<meta name="description" content="un sitio para la educación" />
		

<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />
	

<title>Administración de medios</title>
	
<?php


include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);


$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }

mysqli_free_result($resultado);
mysqli_close($db_connection);

?>


</head>

	
	
<body>

	
	
<div id="wrapper">
<div id="logo">
				

<?php
	
include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado1=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Dominio=$row1[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
				
				
<p>Medios</p>
							

	</div>
	
		
			
<div id="page" class="round">
			
				
<div id="menu" class="round">
					
<ul>
					
<li><a href="../asesores.php?Idusu= <?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round active">Atras</a></li>
	
<li><a href="../../../../soporte.php?Idusu= <?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round ">Soporte</a></a></li>
						


</ul>	
				
</div>
	
	
		
				
<div id="splash">
					
<img src="../../../ima/medios.jpg" alt="" width="300" height="250" class="round" />

</div>

			
		
<div id="wrapper2" class="round">
						
<div id="sidebar" class="round">
					

<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>

					
<h3>Categorias</h3>
						
					
<ul>
<li>Selecciona la Categoria</li>
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$resultado2=mysqli_query($db_connection, "SELECT Idcat, Categoria FROM Categorias WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Categoria=$row2[Categoria];
          $Idcatx=$row2[Idcat];

if(utf8_decode($_GET['Idcat']) == $Idcatx){
?> 


	<li><a style="color:green;" href="medios.php?Idusu= <?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcatx; ?>"><?php echo $Categoria; ?></a></li>
 
<?php
}else{

?> 


	<li><a style="color:orange;" href="medios.php?Idusu= <?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcatx; ?>"><?php echo $Categoria; ?></a></li>
 



<?php
}
      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
	

						
<h3>Asigna medios al curso</h3>
						

						
<ul>
<li>Seleccionar el curso</li>
				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);


$resultado4=mysqli_query($db_connection, "SELECT Idcur, Curso FROM Cursos WHERE  Idcat = '".$Idcat."' &&  Idusu = '".$Idusu."' && Estado=1 ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
	  $Curso=$row4[Curso];
 $Idcurx=$row4[Idcur];



if(utf8_decode($_GET['Idcur']) == $Idcurx){
?> 

<li><a  style="color:green;" href="medios.php?Idusu= <?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>"><?php echo $Curso; ?></a><a href="regmedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>&Idtem=<?php echo $Idtem; ?>"> Agrega</a></li>


<?php
include '../../../cdb/db.php';
$Idcur = utf8_decode($_GET['Idcur']);
$resultado3=mysqli_query($db_connection, "SELECT Idmed, Medio, Orden FROM Medios WHERE  Idtab = '".$Idcur."' && Tabla='".Cursos."' ORDER BY Orden  ");
if (mysqli_num_rows($resultado3)>0)
while ($row3 =mysqli_fetch_array($resultado3)) 
	  {
 $Idmed=$row3[Idmed];
 $Medio=$row3[Medio];
 $Orden=$row3[Orden];
?> 
<li><a style="color:red;" ><?php echo $Orden; ?>  <?php echo $Medio; ?> </a> <a href="delmedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>&Idmed=<?php echo $Idmed; ?>">Quita</a>   <a href="updmedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>&Idmed=<?php echo $Idmed; ?>">Actualiza</a></li>
<?php
      }
mysqli_free_result($resultado3);

 ?>

 	<?php
}else{

?> 
 <li><a  style="color:orange;" href="medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>"><?php echo $Curso; ?></a>   <a href="regmedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>&Idtem=<?php echo $Idtem; ?>">Agrega</a>   <a href="delmedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>">Quita</a>   <a href="updmedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>"> Actualiza</a></li>

<?php
}
      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>
</li>

</ul>
					
		
<h3>Asigna medios al tema</h3>
						

						
<ul>
<li>Seleccionar el tema      </li>
				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idtem = utf8_decode($_GET['Idtem']);

$resultado5=mysqli_query($db_connection, "SELECT Idtem, Tema FROM Temas WHERE  Idcur = '".$Idcur."' && Estado=1 ");

if (mysqli_num_rows($resultado5)>0)
{			  
      while ($row5 =mysqli_fetch_array($resultado5)) 
	  {
	  $Tema=$row5[Tema];
 $Idtemx=$row5[Idtem];



if(utf8_decode($_GET['Idtem']) == $Idtemx){
?> 

<li><a  style="color:green;" 
href="medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtemx; ?>"><?php echo $Tema; ?></a><a href="regmediost.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtemx; ?>">Agrega</a>   </li>


<?php
include '../../../cdb/db.php';
$Idcur = utf8_decode($_GET['Idcur']);
$resultado6=mysqli_query($db_connection, "SELECT Idmed, Medio, Orden FROM Medios WHERE  Idtab = '".$Idtem."' && Tabla='".Temas."' ORDER BY Orden  ");
if (mysqli_num_rows($resultado6)>0)
while ($row6 =mysqli_fetch_array($resultado6)) 
	  {
 $Idmed=$row6[Idmed];
 $Medio=$row6[Medio];
 $Orden=$row6[Orden];
?> 
<li><a style="color:red;" ><?php echo $Orden; ?>  <?php echo $Medio; ?> </a> <a href="delmedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>&Idmed=<?php echo $Idmed; ?>">Quita</a>   <a href="updmedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcurx; ?>&Idmed=<?php echo $Idmed; ?>">Actualiza</a></li>
<?php
      }
mysqli_free_result($resultado6);

 ?>

 	<?php
}else{

?> 
<li><a style="color:orange;" href="medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom;?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtemx; ?>"><?php echo $Tema; ?></a>   <a href="regmediost.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtemx; ?>">Agrega</a>  </li>
<?php
}
      }
}
mysqli_free_result($resultado5);
mysqli_close($db_connection);
 ?>
</li>

</ul>		

		
<h3>Asigna medios al subtema</h3>
						

						
<ul>
<li>Seleccionar el subtema      </li>
				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);

$resultado7=mysqli_query($db_connection, "SELECT Idsub, Subtema FROM Subtemas WHERE  Idtem = '".$Idtem."' && Estado=1 ");

if (mysqli_num_rows($resultado7)>0)
{			  
      while ($row7 =mysqli_fetch_array($resultado7)) 
	  {
	  $Subtema=$row7[Subtema];
 $Idsubx=$row7[Idsub];



if(utf8_decode($_GET['Idsub']) == $Idsubx){
?> 

<li><a  style="color:green;" 
href="medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?>"><?php echo $Subtema; ?></a>   <a href="regmediosst.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?> ">Agrega</a>   </li>


<?php
include '../../../cdb/db.php';
$Idcur = utf8_decode($_GET['Idcur']);
$resultado8=mysqli_query($db_connection, "SELECT Idmed, Medio, Orden FROM Medios WHERE  Idtab = '".$Idsub."' && Tabla='".Subtemas."' ORDER BY Orden  ");
if (mysqli_num_rows($resultado8)>0)
while ($row8 =mysqli_fetch_array($resultado8)) 
	  {
 $Idmed=$row8[Idmed];
 $Medio=$row8[Medio];
 $Orden=$row8[Orden];
?> 
<li><a style="color:red;" ><?php echo $Orden; ?>  <?php echo $Medio; ?> </a> <a href="delmedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idmed=<?php echo $Idmed; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?>">Quita</a>   <a href="updmedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idmed=<?php echo $Idmed; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?>"> Actualiza</a></li>
<?php
      }
mysqli_free_result($resultado8);

 ?>

 	<?php
}else{

?> 
<li><a  style="color:orange;" 
href="medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?>"><?php echo $Subtema; ?></a>   <a href="regmediosst.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsubx; ?> ">Agrega</a>   </li>
<?php
}
      }
}
mysqli_free_result($resultado7);
mysqli_close($db_connection);
 ?>
</li>

</ul>		
					
					

<!-- End Sidebar -->				
					
</div>
	
			
		
<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

</html>
