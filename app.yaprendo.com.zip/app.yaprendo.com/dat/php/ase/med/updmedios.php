
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />

		<title></title>

<?php


include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);

$resultado0=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row0 =mysqli_fetch_array($resultado0)) {
   	 $nom=$row0[Nombres];
   }

mysqli_free_result($resultado0);
mysqli_close($db_connection);

?>


	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				
<?php
	
include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado1=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Dominio=$row1[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
			
<p>Actualiza el medio</p>

			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
					<ul>
						
<li><a href="medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>"  title="" class="round active">Atras</a></li>
						
<li><a href="../asesores.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>"  title="" class="round active">Asesores</a></li>

</ul>		
				</div>
				
				<div id="splash">
					<img src="../../../../dat/ima/actualiza.png" alt="" width="300" height="200" class="round" />
				</div>
				
	

	
<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>


<div id="wrapper2" class="round">					
<div id="sidebar" class="round">					
<h3>Categoria</h3>
<ul>
<li>
<?php
include '../../../cdb/db.php';
$Idcat = utf8_decode($_GET['Idcat']);
$resultado2=mysqli_query($db_connection, "SELECT Categoria FROM Categorias WHERE  Idcat = '".$Idcat."' ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Categoria=$row2[Categoria];
?>
	<li><a style="color:green;"><?php echo $Categoria; ?> </a></li>

<?php
      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
	

<h3>Curso</h3>	
<ul>
<li>
<?php
include '../../../cdb/db.php';
$Idcur = utf8_decode($_GET['Idcur']);
$resultado4=mysqli_query($db_connection, "SELECT Curso FROM Cursos WHERE  Idcur= '".$Idcur."' ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
	  $Curso=$row4[Curso];
?> 

<li><a  style="color:green;"><?php echo $Curso; ?></a></li>

<?php
      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>
</li>

</ul>
					
<?php
include '../../../cdb/db.php';
$Idmed = utf8_decode($_GET['Idmed']);
$resultado5=mysqli_query($db_connection, "SELECT Medio, Descrip, Orden, Url FROM Medios WHERE  Idmed= '".$Idmed."' ");

if (mysqli_num_rows($resultado5)>0)
{			  
      while ($row5 =mysqli_fetch_array($resultado5)) 
	  {
$med=$row5[Medio];
$des=$row5[Descrip];
$ord=$row5[Orden];
$url=$row5[Url];
      }
}
mysqli_free_result($resultado5);
mysqli_close($db_connection);
 ?>

<h3>Actualiza el Medio</h3>
<ul>
<li> 
<?php

if($med=="imagen" || $med=="Imagen"){
 ?>
<li align="center">
<img src="<?php echo $url; ?>" alt="" width="300" height="300" class="round" />
</li>
<?php }
if($med=="video" || $med=="Video" || $med=="Vídeo"){
  ?>
<li align="center">
<video src="<?php echo $url; ?>" width="300" height="300" controls>
</li>		
<?php }
if($med=="audio" || $med=="Audio"){
  ?>
<li align="center">
<video src="<?php echo $url; ?>" width="300" height="300" controls>
</li>		
<?php }
if($med=="documento" || $med=="Documento"){
  ?>
<li align="center">
<a href="<?php echo $url; ?>"  title="<?php echo $url; ?>" class="round active"><?php echo $url; ?></a>
</li>		
<?php



}
  ?>
</li>		

<form action="pupdmedios.php" method="POST">

          
<div>
<div>

  <input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>"> 
  <input type="hidden" name="Iddom" value="<?php echo utf8_decode($_GET['Iddom']); ?>">
  <input type="hidden" name="Idcat" value="<?php echo utf8_decode($_GET['Idcat']); ?>"> 
  <input type="hidden" name="Idcur" value="<?php echo utf8_decode($_GET['Idcur']); ?>">
  <input type="hidden" name="Idmed" value="<?php echo utf8_decode($_GET['Idmed']); ?>">
  <input type="hidden" name="Idtem" value="<?php echo utf8_decode($_GET['Idtem']); ?>">
  <input type="hidden" name="Idsub" value="<?php echo utf8_decode($_GET['Idsub']); ?>">


<select name="med">
<option value="<?php echo $med; ?>"><?php echo $med=ucwords($med); ?></option>
<option value="imagen">Imagen</option>
<option value="video">Vídeo</option>
<option value="audio">Audio</option>
<option value="documento">Documento</option>
</select>

 </div>  
 </div>
                

<div>
<div>

<textarea class="form-control" name="des" rows="20"  cols="40"  ><?php echo $des; ?> </textarea>
</div>
</div>


<div>
<div>
<input type="text" name="url" size="35" class="form-control" class="form-input" value="<?php echo $url; ?>" required>

</div>
</div>

<div>
<div>
<input type="text" name="ord" class="form-control" class="form-input" value="<?php echo $ord; ?>" required>
</div>  
</div>

<div>
<div>
<button type="submit">Actualiza</button>
</div>
</div>
</form>






</li>
						</ul>	
					
					
					<!-- End Sidebar -->				
					</div>

				<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>	

		<div id="footer">
			<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		</div>
		
		
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	
</html>
