
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

		<meta name="keywords" content="" />
		<meta name="description" content="" />

<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />


		<title>Medios</title>

		<?php


include '../../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }

mysqli_free_result($resultado);
mysqli_close($db_connection);

?>

		
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
			
<?php
	
include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado1=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Dominio=$row1[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
				
				<p>Vincular el Medio</p>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
					<ul>
<li><a href="../../../../index.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round active">Inicio</a></li>
<li><a href="medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round">Medios</a></li>
					</ul>	
				</div>
				
				<div id="splash">
<img src="../../../ima/archivo.jpg" alt="" width="300" height="200" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
									
<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>

		<h3>Asigna medio al subtema</h3>
						<ul>


<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);

$resultado4=mysqli_query($db_connection, "SELECT Subtema FROM Subtemas WHERE  Idsub = '".$Idsub."'  ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
	  $Subtema=$row4[Subtema];
         

?> 

<li><?php echo $Subtema; ?> 

<?php

      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>
</li>



<li> 



        <p>
<form action="pmedios.php" method="POST">

<div>        
<div>

  <input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>"> 
  <input type="hidden" name="Iddom" value="<?php echo utf8_decode($_GET['Iddom']); ?>">
  <input type="hidden" name="Idcat" value="<?php echo utf8_decode($_GET['Idcat']); ?>"> 
  <input type="hidden" name="Idcur" value="<?php echo utf8_decode($_GET['Idcur']); ?>">
  <input type="hidden" name="Idmed" value="<?php echo utf8_decode($_GET['Idmed']); ?>">
  <input type="hidden" name="Idtem" value="<?php echo utf8_decode($_GET['Idtem']); ?>">
  <input type="hidden" name="Idtab" value="<?php echo utf8_decode($_GET['Idsub']); ?>">
  <input type="hidden" name="Idsub" value="<?php echo utf8_decode($_GET['Idsub']); ?>">

<input type="hidden" name="Tabla" value="Subtemas">



<select name="med">
<option value="imagen">Imagen</option>
<option value="video">Vídeo</option>
<option value="audio">Audio</option>
<option value="documento">Documento</option>
</select>

    </div>
   </div>
                

<div>            
<div>
                        <textarea class="form-control" name="des" rows="20"cols="40" placeholder="Descripcion"></textarea>
       </div>
                </div>
 <div>               <div>
<input type="text" name="url" size="35" class="form-control" placeholder="Url" class="form-input"
                            required>
            </div>  
 </div>  
 <div>               <div>
<input type="text" name="ord" class="form-control" placeholder="Orden" class="form-input"
                            required>
            </div>  
 </div>  

 <div>
                    <div>
                        <button type="submit">Asignar</button>
                                   </div>
                </div>
            </form>





</li>
						</ul>
					
					
					<!-- End Sidebar -->				
					</div>
				
		<div id="footer">
			<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		</div>
		
		
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	
</html>
