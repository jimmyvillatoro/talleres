
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="talleres, cursos, manuales, tutoriales, enseñanza, educacion, aprender, educando," />
<meta name="description" content="un sitio para la educacion" />
<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
<title>Administración</title>
</head>

<body>
<div id="wrapper">
<div id="logo">
<?php
	
include 'dat/cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$resultado=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");
if (mysqli_num_rows($resultado)>0)
{			  
      while ($row =mysqli_fetch_array($resultado)) 
	  {
	  $Dominio=$row[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
 
<?php
      }
}

mysqli_free_result($resultado);
mysqli_close($db_connection);
 ?>
				
				
<p>Administración</p>
			
</div>
	
	
			
<div id="page" class="round">
<div id="menu" class="round">
<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
</ul>	
</div>
	

				
<div id="splash">
<img src="dat/ima/splash.jpg" alt="" width="300" height="200" class="round" />
</div>

			
		
<div id="wrapper2" class="round">
						
<div id="sidebar" class="round">

					
						
<h3>Tus Cursos</h3>
						
<ul>
	
<li>Todos los cursos que tienes en linea</li>
					   
<li><a href="#">Curso de Prueba</a></li>
						   
<li><a href="#"></a></li>
						
<li><a href="#"></a></li>
						
<li><a href="#"></a></li>
						
</ul>

<h3>Tus Alumnos</h3>
						
<ul>

<li>Control de alumnos</li>
						   
<li><a href="#">Reportes</a></li>
						   
<li><a href="#">Altas</a></li>

<li><a href="#">Bajas</a></li>
						
<li><a href="#">Actualiza</a></li>
						
</ul>

<h3>Seguimiento</h3>
						
<ul>

<li>Control educativo por alumno</li>
						   
<li><a href="#">Reportes</a></li>
						   		
<li><a href="#">Actualiza</a></li>
						
</ul>

<h3>Crear Cursos</h3>
						
<ul>

<li>Control de Talleres y Cursos</li>
						   
<li><a href="#">Reportes</a></li>
						   
<li><a href="#">Altas</a></li>

<li><a href="#">Bajas</a></li>
						
<li><a href="#">Actualiza</a></li>
						
</ul>
				
						
						
<h3>Información</h3>
						
<ul>
						   
<li>Los datos están seguros en la nube, pero puedes tener instalada /nuestra plataforma en tu sitio web.</li>
						   
<li>.</li>
						   
<li>Nosotros hicimos está plataforma pensando en un bien común para la humanidad, pero tú puedes instalarla en tu sitio web gratis.</li>
						   
<li>Comunicate con nosotros.</li>
						
</ul>

						
<h3>Video tutorial</h3>
		
<ul>

<li>video html
						
<video src="dat/vid/html.mp4"  width="300" height="300" controls>
						
						
						
</li>
						
</ul>
					
					
<!-- End Sidebar -->				
					
</div>
	
			
		
<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

</html>
