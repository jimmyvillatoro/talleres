
<html lang="ES">
	
<head>
		
	
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		

<meta name="keywords" content="talleres, cursos, manuales, tutoriales, enseñanza, educación, aprender, educando," />
		

<meta name="description" content="un sitio para la educación" />
		

<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
	

<title>Administra Tú Taller</title>
	
<?php


include 'dat/cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);


$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }


?>
</head>

	
	
<body>

	
	
<div id="wrapper">
<div id="logo">
				

<?php
	
include 'dat/cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado)>0)
{			  
      while ($row =mysqli_fetch_array($resultado)) 
	  {
	  $Dominio=$row[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado);
mysqli_close($db_connection);
 ?>
				
				
<p><a style="color:orange;"> Control T y S </a></p>
			
</div>
	
		
			
<div id="page" class="round">
			
				
<div id="menu" class="round">
					
<ul>
						
<li><a href="asesores.php" title="" class="round active">atras</a></a></li>
						
<li><a href="soporte.php" title="" class="round">Soporte</a></li>

</ul>	
				
</div>
	
	
		
				
<div id="splash">
					
<img src="dat/ima/splash.jpg" alt="" width="300" height="200" class="round" />

</div>

			
		
<div id="wrapper2" class="round">
<div id="sidebar" class="round">

<h3>Categoria</h3>
						
<ul>
<li><a href="regcategoria.php">Actualizar</a></li>
</ul>
	
						
<h3>Curso</h3>
						
<ul> 
<li><a href="#">Actualizar</a></li>
</ul>

				
<h3>Temas</h3>
						
<ul>
<li>Control de Temas</li>				   
<li><a href="#">Reportes</a></li>
<li><a href="regtema.php">Altas</a></li>
<li><a href="#">Bajas</a></li>
<li><a href="#">Actualiza</a></li>
</ul>
				
						
<h3>Subtemas</h3>
						
<ul>
<li>Control de Subtemas</li>
<li><a href="#">Reportes</a></li>
<li><a href="regsubtema.php">Altas</a></li>
<li><a href="#">Bajas</a></li>
<li><a href="#">Actualiza</a></li>
</ul>
							
						
<h3>Información</h3>
						
<ul>
<li>En esta área creas los temas y subtemas del curso seleccionado</li>
<li>Crea tu curso a la medida de tu capacidad</li>
<li>Comunicate con nosotros.</li>
</ul>

						

					
<!-- End Sidebar -->				
					
</div>
	
			
		
<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

</html>
