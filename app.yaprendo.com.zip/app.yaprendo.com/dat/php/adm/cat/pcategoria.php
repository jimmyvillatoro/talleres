<?php

include 'dat/cdb/db.php';

$cat = $_REQUEST['cat'];
$des = $_REQUEST['des'];
$ord = $_REQUEST['ord'];
$est = 1;
$idd = 1;

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$resultado=mysqli_query($db_connection, "SELECT Idcat FROM Categorias WHERE Categoria = '".$cat."' ");
 

if (mysqli_num_rows($resultado)>0)
	{
header('Location: selcategorias.php?cat='.$cat.'');
}
  else {


$insert_value ="INSERT INTO Categorias (Categoria, Descrip, Orden, Estado, Iddom ) VALUES ( '".$cat."' ,  '".$des."', '".$ord."', '".$est."', '".$idd."')";

$retry_value = mysqli_query($db_connection,$insert_value);



header('Location: asesores.php');

}

mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
