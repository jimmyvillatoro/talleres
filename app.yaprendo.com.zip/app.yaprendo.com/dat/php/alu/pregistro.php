<?php

include '../../cdb/db.php';

$nom = $_REQUEST['nom'];
$ape = $_REQUEST['ape'];
$mov = $_REQUEST['mov'];
$cor = $_REQUEST['cor'];
$pas = $_REQUEST['pas'];
$des = $_REQUEST['des'];
$men=  $_REQUEST['men'];
$tip=  $_REQUEST['tip'];
$Iddom= utf8_decode($_REQUEST['Iddom']);

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$resultado=mysqli_query($db_connection, "SELECT Idusu FROM Usuarios WHERE Correo = '".$cor."' ");
 

if (mysqli_num_rows($resultado)>0)
{
//falta enviarlo a correo dado de alta
header('Location: ../../../index.php?Iddom='.$Iddom.'');
 } else {


$insert_value = "INSERT INTO Usuarios (Nombres, Apellidos, Correo, Movil, Pass, Mensaje, Descrip, Estado, Tipo, Idrus, Iddom) VALUES ('".$nom."',  '".$ape."',  '".$cor."',  '".$mov."',  '".$pas."', '".$men."',  '".$des."', 0,'".$tip."',0, 1)";

	$retry_value = mysqli_query($db_connection,$insert_value);


$cuerpo="'Nombre: '.$nom.'  Movil: '.$mov.'  Correo: '.$cor.'  Comentario: '.$men";

mail("jimmyvillatoro77@hotmail.com","Un Prospecto dale seguimiento->",$cuerpo,"Equipo El Taller");

$resultado1=mysqli_query($db_connection, "SELECT Idusu FROM Usuarios WHERE Correo = '".$cor."' ");

while ($row1 =mysqli_fetch_array($resultado1)) {
   	 $Idusu=$row1[Idusu];
   }
mysqli_free_result($resultado1);



header('Location: alumnos.php?Iddom='.$Iddom.'&Idusu='.$Idusu.'');

}

mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
