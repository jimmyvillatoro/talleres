
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />
				
<?php
	
include '../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idtip = utf8_decode($_GET['Idtip']);

$resultado=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado)>0)
{			  
      while ($row =mysqli_fetch_array($resultado)) 
	  {
	  $Dominio=$row[Dominio];

      }
}

mysqli_free_result($resultado);
mysqli_close($db_connection);
 ?>

        <title>registro alumnos</title>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">

				
<h1><?php echo $Dominio; ?><span></span></h1>
	
				<p>registro alumnos</p>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
					<ul>
<li><a href="../../../index.php?Iddom=<?php echo $Iddom; ?>" title="" class="round active">Inicio</a></li>
<li><a href="../../../contacto.php?Iddom=<?php echo $Iddom; ?> " title="" class="round">Contacto</a></li>
					</ul>	
				</div>
				
				<div id="splash">
<img src="../../ima/splash.jpg" alt="" width="300" height="200" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
				
						<h3>Registro de alumno</h3>
						<ul>
<li> 



        <p>
            <form action="pregistro.php" method="POST">
                <p align="justify"> Se parte del Equipo </p>
                <div>
                    <div>

<input type="hidden" name="tip" value="<?php echo utf8_decode($_GET['tip']); ?>">   
<input type="hidden" name="Iddom" value="<?php echo utf8_decode($_GET['Iddom']); ?>">   
       
 <input type="text" name="nom" class="form-control" placeholder="Nombres" class="form-input"
                            required>
                    </div>
                    <div>
                        <input type="text" name="ape" class="form-control" placeholder="Apellidos"
                            class="form-input" required>
                    </div>
                </div>
<div>
                    <div>
                        <input type="email" name="cor" class="form-control" placeholder="Correo" class="form-input"
                            required>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" name="mov" class="form-control" placeholder="Movil" class="form-input"
                            required>
                    </div>
                </div>
                  <div>
                    <div>
                        <input type="password" name="pas" class="form-control" placeholder="Contraseña" class="form-input"
                            required>
                    </div>
                </div>

                <div>
                    <div>
                        <textarea class="form-control" name="men" rows="3" placeholder="Mensaje­"></textarea>
                    </div>
                </div>

 <div>
                    <div>
                        <textarea class="form-control" name="des" rows="4" placeholder="Describete"></textarea>
                    </div>
                </div>

                <div>
                    <div>
                        <button type="submit">¡Unirme!</button>
                                   </div>
                </div>
            </form>

           
           
           
<p id="ad">Inicia Sesión</p>
<ul>    
    <li><a href="../../../sesion.php?Iddom=<?php echo $Iddom; ?>" title="" 
class="round">Miembros</a></li>
                    </ul>
           
    



</li>
						</ul>
					
					<!-- End Sidebar -->				
					</div>
				
		<div id="footer">
			<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		</div>
		
		
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	
</html>
