
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

<meta name="keywords" content="talleres, cursos, manuales, tutoriales, enseñanza, educación, aprender, educando," />
<meta name="description" content="un sitio para la educación" />
<link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />
<title>Edita tu perfil</title>
	
<?php


include '../../cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }

mysqli_free_result($resultado);
mysqli_close($db_connection);

?>
</head>


<body>

<div id="wrapper">
<div id="logo">
				

<?php
	
include '../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);

$resultado1=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Dominio=$row1[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
				
				
<p><a style="color:orange;"> Tu perfil</a></p>

</div>
	
		
			
<div id="page" class="round">
		
<div id="menu" class="round">
					
<ul>
						
<li><a href="alumnos.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round active">Atras</a></li>
						
<li><a href="../../../soporte.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round">Soporte</a></li>

</ul>	
				
</div>
	
				
<div id="splash">
					
<img src="../../../dat/ima/user.jpeg" alt="" width="300" height="200" class="round" />

</div>

			
		
<div id="wrapper2" class="round">
<div id="sidebar" class="round">

<h3>Alumno</h3>
		
<ul>

<li>
<?php


include '../../cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);


$resultado2=mysqli_query($db_connection, "SELECT Nombres, Apellidos, Correo, Movil FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row2 =mysqli_fetch_array($resultado2)) {
   	 $nom=$row2[Nombres];
   	 $ape=$row2[Apellidos];
   	 $cor=$row2[Correo];
   	 $mov=$row2[Movil];

?> 


<li><a style="color:black;"><?php echo $nom; ?> <?php echo $ape; ?></a>
<a href="updperfil.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> Actualiza </a></li>
 

<?php

      }

mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>


						
<h3>Foto</h3>
						
					
<ul>
<li>Selecciona tú Foto</li>
<li>		
</ul>

				
							
						
<h3>Información</h3>
						
<ul>
<li>En esta área creas los temas y subtemas del curso seleccionado</li>
<li>Crea tu curso a la medida de tú capacidad</li>
<li>Comunicate con nosotros.</li>
</ul>

						

					
<!-- End Sidebar -->				
					
</div>
	
<p><a style="color:orange;"> <?php echo $nom; ?> </a></p>
		
<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

</html>
