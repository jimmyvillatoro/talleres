
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

<meta name="keywords" content="talleres, cursos, manuales, tutoriales, enseñanza, educación, aprender, educando," />
<meta name="description" content="un sitio para la educación" />
<link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta charset="UTF-8">	

<title>Ver Medios</title>
	
<?php


include '../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);


$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row =mysqli_fetch_array($resultado)) 
   	 $nom=$row[Nombres];
   

mysqli_free_result($resultado);
mysqli_close($db_connection);

?>


</head>
<body>
<div id="wrapper">
<div id="logo">
<?php
	
include '../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado1=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado1)>0)
while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Dominio=$row1[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }


mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
				
				
<p></p>
	</div>
		</div>
		
			
<div id="page" class="round">
<div id="menu" class="round">
<ul>
<li><a href="versubtemasx.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>" title="" class="round active">Atrás</a></li>

</ul>	
</div>

<p>Alumno:<a style="color:orange;"> <?php echo $nom; ?> </a></p>


<?php
include '../../cdb/db.php';
$Idtem = utf8_decode($_GET['Idtem']);
$Tabla ="Subtemas";
$result4=mysqli_query($db_connection, "SELECT Medio, Url FROM Medios WHERE  Idtab = '".$Idsub."' && Tabla='".$Tabla."'");

if (mysqli_num_rows($result4)>0) 
while ($row4 =mysqli_fetch_array($result4)) 
	  {

$med4=$row4[Medio];
$url4=$row4[Url];

if($med4=="imagen"){
 ?>

<img src="<?php echo $url4; ?>" alt="" width="200" height="200" class="round" />

<?php }
if($med4=="video"){
  ?>

<video src="<?php echo $url4; ?>" width="300" height="600" controls>

<?php }
if($med4=="audio"){
  ?>

<video src="<?php echo $url4; ?>" width="300" height="100" controls>

<?php }
if($med4=="documento"){
  ?>

<a href="<?php echo $url4; ?>"  title="<?php echo $url4; ?>" class="round active"><?php echo $url4; ?></a>

<?php 
}
      }//medios
mysqli_free_result($result4);

mysqli_close($db_connection);
 ?>



<!-- End Sidebar -->				
					
</div>
	
		

		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>
</div>

</body>



</html>
