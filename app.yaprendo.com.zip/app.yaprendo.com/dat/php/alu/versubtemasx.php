
<html lang="ES">
<head>
<meta http-equiv="Content-Type" content="text/html;  charset=utf-8" />

<meta name="keywords" content="talleres, cursos, manuales, tutoriales, enseñanza, educación, aprender, educando," />
<meta name="description" content="un sitio para la educación" />
<link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta charset="UTF-8">	

<title>Ver Curso</title>
	
<?php


include '../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);


$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row =mysqli_fetch_array($resultado)) 
   	 $nom=$row[Nombres];
   

mysqli_free_result($resultado);
mysqli_close($db_connection);

?>


</head>
<body>
<div id="wrapper">
<div id="logo">
<?php
	
include '../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);


$resultado1=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado1)>0)
while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Dominio=$row1[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }


mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
				
				
<p></p>
	</div>
		</div>
		
			
<div id="page" class="round">
<div id="menu" class="round">
<ul>
<li><a href="vercursox.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>" title="" class="round active">Atrás</a></li>

</ul>	
</div>

					
<p>Alumno:<a style="color:orange;"> <?php echo $nom; ?> </a></p>



<?php
include '../../cdb/db.php';

$Idtem = utf8_decode($_GET['Idtem']);

$result2=mysqli_query($db_connection, "SELECT Idsub, Subtema, Descrip, Orden from Subtemas  WHERE Idtem='".$Idtem."' and Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($result2)>0)
while ($row2 =mysqli_fetch_array($result2)) 
	  {

$Subtema2=$row2[Subtema];
$Idsub2=$row2[Idsub];
$Descrip2=$row2[Descrip];
$Orden2=$row2[Orden];

?> 
<br>
<h3>
<a style="color:green;"><?php echo $Orden2; ?>.-<?php echo $Subtema2; ?></a>
</h3>
<br>
<a style="color:orange;" ><?php echo $Descrip2; ?></a>
<br>
<br>
<a href="vermedios2x.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsub2; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>" >ver medio</a>  
<br>
<br>



<?php
}//temas

mysqli_free_result($result2);

mysqli_close($db_connection);
 ?>



<!-- End Sidebar -->				
					
</div>
	
		

		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>
</div>

</body>



</html>
