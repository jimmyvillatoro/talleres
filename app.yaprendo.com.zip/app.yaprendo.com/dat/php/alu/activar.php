<?php

include '../../cdb/db.php';


$Iddom= $_REQUEST['Iddom'];
$Idusu= $_REQUEST['Idusu'];
$Idcur= $_REQUEST['Idcur'];
$Idfin= $_REQUEST['Idfin'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


//http://app.yaprendo.com/dat/php/alu/activar.php?Iddom=1&Idusu=1&Idcur=2&Idfin=2   

$Aprobar="Aceptado por el alumno";
$Apr="Pendiente";

$update_value ="UPDATE Controlescolar SET Aprobar='".$Aprobar."', Fecha='".$date."', Hora='".$time."'  WHERE Idfin='".$Idfin."' && Aprobar='".$Apr."' ";
$retry_value = mysqli_query($db_connection,$update_value);



header('Location: http://app.yaprendo.com/index.php?Iddom='.$Iddom.'');


mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
