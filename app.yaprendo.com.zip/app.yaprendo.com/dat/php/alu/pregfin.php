<?php

include '../../cdb/db.php';


$Iddom= utf8_decode($_GET['Iddom']);
$Idusu= utf8_decode($_GET['Idusu']);
$Idcur= utf8_decode($_GET['Idcur']);

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$resultado=mysqli_query($db_connection, "SELECT Idfin FROM Finanzas WHERE Idalu = '".$Idusu."' && Idcur = '".$Idcur."'");
 

if (mysqli_num_rows($resultado)>0)
{
header('Location: vercurso.php?Iddom='.$Iddom.'&Idusu='.$Idusu.'&Idcur='.$Idcur.'');
 } else {



$result=mysqli_query($db_connection, "SELECT Curso, Costo, Promo, Precio, Tipo FROM Cursos WHERE Idcur = '".$Idcur."' && Estado=1");

while ($rowx1 =mysqli_fetch_array($result)) {
$Curso=$rowx1[Curso];
$Costo=$rowx1[Costo];
$Promo=$rowx1[Promo];
$Precio=$rowx1[Precio];
$Tipo=$rowx1[Tipo];
   }
mysqli_free_result($result);


$Desc=$Precio-$Promo;

$insert_value = "INSERT INTO Finanzas (Monto, Descu, Descrip, Fecha, Hora, Tipo, Idalu, Idcur, Idase, Idadm) VALUES ('".$Promo."',  '".$Desc."',  '".$Curso."',  '".$date."',  '".$time."', '".$Tipo."',  '".$Idusu."', '".$Idcur."', 2, 3)";

	$retry_value = mysqli_query($db_connection,$insert_value);


$men="alta a alumno a un curso"; 

$cuerpo="'Curso: '.$Curso.'  Dominio: '.$Iddom.'  Alumno: '.$Idusu.'  Comentario: '.$men";

mail("soporte@yaprendo.com","Un alumno a este curso",$cuerpo,"dale seguimiento.");

$resultado1=mysqli_query($db_connection, "SELECT Idfin FROM Finanzas WHERE Idalu = '".$Idusu."' && Idcur = '".$Idcur."' ");

while ($row1 =mysqli_fetch_array($resultado1)) {
   	 $Idfin=$row1[Idfin];
   }
mysqli_free_result($resultado1);


$Aprobar="Pendiente";

$insert_val = "INSERT INTO Controlescolar (Aprobar, Fecha, Hora, Idfin, Idcer) VALUES ('".$Aprobar."',  '".$date."',  '".$time."', '".$Idfin."', 0)";

	$retry_value = mysqli_query($db_connection,$insert_val);


$resul=mysqli_query($db_connection, "SELECT Nombres, Correo FROM Usuarios WHERE Idusu = '".$Idusu."' ");

while ($rowx2 =mysqli_fetch_array($resul)) {
   	 $Correo=$rowx2[Correo];
     $Nombres=$rowx2[Nombres];
   }
mysqli_free_result($resul);


$men="http://app.yaprendo.com/dat/php/alu/activar.php?Iddom='.$Iddom.'&Idusu='.$Idusu.'&Idcur='.$Idcur.'&Idfin='.$Idfin.'"; 

$cuerpo="'Hola '.$Nombres.', hemos notado que te interesa el curso: '.$Curso.',   para darle seguimiento y puedas obtener el certificado válido oficial en todo México y países afiliados, dale clic a el siguiente enlace de activación '.$men";

mail($Correo,"confirma si deseas este curso",$cuerpo," grácias por asistir.");



header('Location: vercurso.php?Iddom='.$Iddom.'&Idusu='.$Idusu.'&Idcur='.$Idcur.'&Idfin='.$Idfin.'');

}

mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
