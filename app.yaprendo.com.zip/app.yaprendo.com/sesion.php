
<html lang="ES">
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<title>Iniciar Sesión</title>

<?php
	
$Iddom = utf8_decode($_GET['Iddom']);

?>

	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
			
<?php
	
include 'dat/cdb/db.php';

$resultado=mysqli_query($db_connection, "SELECT Dominio FROM Dominios WHERE  Iddom = '".$Iddom."' && Estado=1 ORDER BY Iddom  ");

if (mysqli_num_rows($resultado)>0)
{			  
      while ($row =mysqli_fetch_array($resultado)) 
	  {
	  $Dominio=$row[Dominio];
?> 

<h1><?php echo $Dominio; ?><span></span></h1>
	
 
<?php
      }
}

mysqli_free_result($resultado);
mysqli_close($db_connection);
 ?>
				
				<p>Acceder</p>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
					<ul>
<li><a href="index.php?Iddom=<?php echo $Iddom; ?>" title="" class="round active">Inicio</a></li>
<li><a href="contacto.php?Iddom=<?php echo $Iddom; ?>" title="" class="round">Contacto</a></li>
					</ul>	
				</div>
				
				<div id="splash">
<img src="dat/ima/sesion.jpg" alt="" width="300" height="100" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
				
						<h3>Acceder</h3>
						<ul>
						   <li> 


<p>
            <p>Inicia sesión.
             <div>
      <form action="psesion.php" method="POST">
             <div>
             <div>
<input type="hidden" name="Iddom" value="<?php echo 
utf8_decode($_GET['Iddom']); ?>">   

<input type="text" name="cor" class="form-control"              placeholder="Correo Electrónico" class="form-input" required>
             </div>
             <div>
             <div>
<input type="password" name="pas" class="form-control" placeholder="Contraseña"                              class="form-input" required>
             </div>
             </div>
             </div>

             <div>
             <div>
<button type="submit" class="btn btn-success">Iniciar Sesión</button>

             </div>
             </div>
             </form>
         </p>
    </div>
    </p>


<p>

	<ul>
						   <li> 
Registrate como alumno. <a href="dat/php/alu/registro.php?tip=1&Iddom=<?php echo $Iddom; ?>" title="Registro" target="_top">
<strong>Crea una cuenta.</a></strong>
	</li>
<img src="dat/ima/registro.jpg" alt="" width="300" height="200" class="round" />

						   <li> 
Registrate como asesor. <a href="dat/php/ase/regasesor.php?tip=2&Iddom=<?php echo $Iddom; ?>" title="Inicio" target="_top">
<strong>Crea tú taller.</a></strong>
	</li>
						   </ul> 

    </p>



</li>
						</ul>
					
					<!-- End Sidebar -->				
					</div>
				
		<div id="footer">
			<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		</div>
		
		<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>

</body>

</html>
