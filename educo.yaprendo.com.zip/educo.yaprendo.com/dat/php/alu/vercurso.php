<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title></title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>El Taller <span>com</span></h1>
				<p>Cursos y Talleres.</p>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
					<ul>
<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="#" title="" class="round  active">Acceso</a></li>
<li><a href="#" title="" class="round">Servicios</a></li>
<li><a href="#" title="" class="round">Acerca de</a></li>
<li><a href="#" title="" class="round">Donar</a></li>
<li><a href="#" title="" class="round">Soporte</a></li>
					</ul>	
				</div>
				
				<div id="splash">
					<img src="../../ima/splash.jpg" alt="" width="960" height="400" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
			<li><a href="index.html">Inicio</a></li>
			<li><a href="#">Acerca de</a></li>
    <li><a href="#">Contactanos</a></li>
			<li><a href="#">Soporte</a></li>
			
			</ul>				
						
						<h3>Asesores</h3>
						<ul>
						   <li>Registro</li>
						   <li>Control de Alumnos</li>
						   <li>Certificados</li>
						   <li>Finanzas</li>
						</ul>

						<h3>Alumnos</h3>
						<ul>
		   <li>Registro</li>
           <li>Seguimiento de cursos</li>
           <li>Control de Diplomas</li>
           <li>Inscripción a cursos</li>
						</ul>

       <h3>Administración</h3>
						<ul>
			<li>Acceso al Portal</li>
    <li>Sistema</li>
    <li>Asesores</li>
    <li>Alumnos</li>
    <li>Cursos</li>
    <li>Certificados</li>
						</ul>

 <h3>Soporte</h3>
						<ul>
			<li>Ticket</li>
    <li>Llamar</li>
    <li>Correo</li>
    <li>Mensaje</li>
    <li>Chat</li>
						</ul>
					
					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">
					


<p>Alumno:<a style="color:orange;"> <?php echo $nom; ?> </a></p>


<?php
include '../../cdb/db.php';

$Idcur = utf8_decode($_GET['Idcur']);
$result=mysqli_query($db_connection, "SELECT Curso, Descrip FROM Cursos WHERE  Idcur = '".$Idcur."' && Estado=1  ");

if (mysqli_num_rows($result)>0)
while ($rowx =mysqli_fetch_array($result)) 
	  {
	$Cursox=$rowx[Curso];
 $Descripx=$rowx[Descrip];

?> 
<h3>Curso: <a style="color:black;" ><?php echo $Cursox; ?></a></h3>

<br>
<a style="color:orange;" ><?php echo $Descripx; ?></a>
<br>
<br>
<?php

$Idcur = utf8_decode($_GET['Idcur']);
$Tabla ="Cursos";
$result3=mysqli_query($db_connection, "SELECT Medio, Url FROM Medios WHERE  Idtab = '".$Idcur."' && Tabla='".$Tabla."'");

if (mysqli_num_rows($result3)>0) 
while ($row3 =mysqli_fetch_array($result3)) 
	  {

$med3=$row3[Medio];
$url3=$row3[Url];

if($med3=="imagen"){
 ?>

<img src="<?php echo $url3; ?>" alt="" width="300" height="300" class="round"  />

<?php }
if($med3=="video"){
  ?>

<video src="<?php echo $url3; ?>"  width="300" height="300" controls>

<?php }
if($med3=="audio"){
  ?>

<video src="<?php echo $url3; ?>"  width="300" height="100" controls>

<?php }
if($med3=="documento"){
  ?>

<a href="<?php echo $url3; ?>"  title="<?php echo $url3; ?>" class="round active"><?php echo $url3; ?></a>

<?php }


      }//medios
mysqli_free_result($result3);
 
      }//cursos
mysqli_free_result($result);
mysqli_close($db_connection);
 ?>



<?php
include '../../cdb/db.php';

$Idcur = utf8_decode($_GET['Idcur']);

$result2=mysqli_query($db_connection, "SELECT Idtem, Tema, Descrip, Orden from Temas  WHERE Idcur='".$Idcur."' and Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($result2)>0)
while ($row2 =mysqli_fetch_array($result2)) 
	  {

$Tema2=$row2[Tema];
$Idtem2=$row2[Idtem];
$Descrip2=$row2[Descrip];
$Orden2=$row2[Orden];

?> 
<br>
<br>
<h3>
<a style="color:green;"><?php echo $Orden2; ?>.-<?php echo $Tema2; ?></a>
</h3>
<br>
<a style="color:orange;" ><?php echo $Descrip2; ?></a>
<br>
<br>
<a href="vermedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idtem=<?php echo $Idtem2; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>" >ver medio</a>  <a href="versubtemas.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idtem=<?php echo $Idtem2; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>" >ver subtema</a>
<br>
<br>



<?php
}//temas

mysqli_free_result($result2);

mysqli_close($db_connection);
 ?>

					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

</html>
