<?php

include '../../cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);

$nom = $_GET['nom'];
$ape = $_GET['ape'];
$cor = $_GET['cor'];
$mov = $_GET['mov'];
$des = $_GET['des'];



$update_value ='UPDATE Usuarios SET Nombres="'.$nom.'", Apellidos="'.$ape.'", Correo="'.$cor.'", Movil="'.$mov.'", Descrip="'.$des.'" WHERE Idusu="'.$Idusu.'" ';



	$retry_value = mysqli_query($db_connection,$update_value);



header('Location: perfil.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'');



mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
