<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Asesores</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include '../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Asesores</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/perfil.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				
				<div id="splash">
					<img src="../../ima/splash.jpg" alt="" width="960" height="400" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/sesion.php" title="" class="round">Acceso</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			
			</ul>				
						

	
		<!-- End Sidebar -->				
					</div>			
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	
	
<h3>Actualiza tu perfil</h3>
<ul>
<li> 

<?php
include '../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);

$resultado2=mysqli_query($db_connection, "SELECT Nombres, Apellidos, Correo, Movil, Descrip FROM Usuarios WHERE  Idusu = '".$Idusu."' ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
   $nom=$row2[Nombres];
   $ape=$row2[Apellidos];
   $cor=$row2[Correo];
   $mov=$row2[Movil];
   $des=$row2[Descrip];

      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>

<p>
<form action="pupdperfil.php" method="POST">
            
<div>
                    <div>

  <input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>"> 
  <input type="hidden" name="Iddom" value="<?php echo utf8_decode($_GET['Iddom']); ?>">

 
 <input type="text" name="nom" class="form-control" class="form-input" value="<?php echo $nom; ?>" required>
                    </div>
        </div>
<div>
                    <div>      
       <input type="text" name="ape" class="form-control" class="form-input" value="<?php echo $ape; ?>" required>
                    </div>
        </div>
        <div>
                    <div>      
       <input type="text" name="cor" class="form-control" class="form-input" value="<?php echo $cor; ?>" required>
                    </div>
        </div>

        <div>
                    <div>      
       <input type="text" name="mov" class="form-control" class="form-input" value="<?php echo $mov; ?>" required>
                    </div>
        </div>

                
                <div>
                    <div>
  <textarea class="form-control" name="des" rows="10"  cols="28"  ><?php echo $des; ?> </textarea>
                    </div>
                </div>

                <div>
                    <div>
                        <button type="submit">Actualiza</button>
                                   </div>
                </div>
            </form>





</li>
						</ul>
					
				
					
<!-- termina aqui -->				
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para la educación altruista</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

	
</html>