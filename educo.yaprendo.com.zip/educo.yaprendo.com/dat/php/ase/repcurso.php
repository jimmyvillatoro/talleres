<?php

require 'fpdf.php';

include '../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']); 
$Idusu = utf8_decode($_GET['Idusu']);
$Idcur = utf8_decode($_GET['Idcur']);



date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


//----------------------LOGO--------------------------//

$result1=mysqli_query($db_connection, "SELECT Dominio, Url  FROM Dominios WHERE Iddom = '".$Iddom."' ");

while ($row1 =mysqli_fetch_array($result1))
	  {
	  $dom=$row1[Dominio];
      $url=$row1[Url];  
	  }

mysqli_free_result($result1);


//----------------------LOGO--------------------------//


$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','',8);
$pdf->Image('../../ima/imprime.png',5,5,-800);
$pdf->Cell(0,8,'                               Fecha: '.$date.' Url: '.$url.' ',0,1);
$pdf->Line(200,20,8,20);
$pdf->Ln(3);



$result2=mysqli_query($db_connection, "SELECT Curso, Descrip  FROM Cursos WHERE Idcur = '".$Idcur."' ");

while ($row2 =mysqli_fetch_array($result2))
	  {
	  $cur=$row2[Curso];
	  $descrip=$row2[Descrip];
	  
      $cur=utf8_decode($cur); 
      $descrip=utf8_decode($descrip);
      
$pdf->Ln(3);
$pdf->Ln(3);
$pdf->SetFont('Arial','',18);
$pdf->Cell(0,8,'Curso:'.$cur,0,5);
$pdf->Ln(3);
$pdf->Ln(3);
$pdf->SetFont('Arial','',12);
$pdf->Write(5,$descrip);

$tabla="Cursos";
$p=20;
$result5=mysqli_query($db_connection, "SELECT Url  FROM Medios WHERE Idtab = '".$Idcur."' && Tabla='".$tabla."' ");

while ($row5 =mysqli_fetch_array($result5))
	  {
	   $urlm=$row5[Url];  
	   $pdf->Image($urlm,25,25,-500);
	  }

mysqli_free_result($result5);

$pdf->Line(200,20,8,20);
$pdf->Ln(3);
$pdf->Ln(3);
$pdf->Ln(3);

	  }

mysqli_free_result($result2);

$result3=mysqli_query($db_connection, "SELECT Idtem, Tema, Descrip  FROM Temas WHERE Idcur = '".$Idcur."' ");
while ($row3 =mysqli_fetch_array($result3))
	  {
	  $Idtem=$row3[Idtem];
	  $tem=$row3[Tema];
	  $des1=$row3[Descrip];
	  
	  $tem=utf8_decode($tem); 
	  $des1=utf8_decode($des1); 

$pdf->SetFont('Arial','',16);
$pdf->Cell(0,$p=$p+8,$tem,0,5);
$pdf->SetFont('Arial','',12);
$pdf->Ln(3);
$pdf->Ln(3);
$pdf->Write(5,$des1);
$pdf->Ln(3);
$pdf->Ln(3);
$pdf->Ln(3);
$p=$p-8;

$result4=mysqli_query($db_connection, "SELECT Idsub, Subtema, Descrip  FROM Subtemas WHERE Idtem = '".$Idtem."' ");

while ($row4 =mysqli_fetch_array($result4))
	  {
	  $Idsub=$row4[Idsub];
	   $sub=$row4[Subtema];
	   $des2=$row4[Descrip];
	   
	  $sub=utf8_decode($sub); 
	  $des2=utf8_decode($des2); 

$pdf->SetFont('Arial','',14);
$pdf->Cell(0,8,$sub,0,5);
$pdf->SetFont('Arial','',12);
$pdf->Ln(3);
$pdf->Ln(3);
$pdf->Write(5,$des2);
$pdf->Ln(3);
     $pdf->Ln(3);  
	  }
mysqli_free_result($result4);
  	  }
mysqli_free_result($result3);



$pdf->Output();	

mysqli_close($db_connection);
?>
