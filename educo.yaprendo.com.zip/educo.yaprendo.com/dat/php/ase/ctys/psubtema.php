<?php

include '../../../cdb/db.php';

$Idusu = utf8_decode($_REQUEST['Idusu']);
$Iddom = utf8_decode($_REQUEST['Iddom']);
$Idcat = utf8_decode($_REQUEST['Idcat']);
$Idcur = utf8_decode($_REQUEST['Idcur']);
$Idtem = utf8_decode($_REQUEST['Idtem']);



$sub = $_REQUEST['sub'];
$des = $_REQUEST['des'];
$ord = $_REQUEST['ord'];
$est = 1;


date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$insert_value ="INSERT INTO Subtemas (Subtema, Descrip, Orden, Estado, Idtem ) VALUES ( '".$sub."' ,  '".$des."', '".$ord."', '".$est."', '".$Idtem."')";


$retry_value = mysqli_query($db_connection,$insert_value);

   if($retry_value)
         {
            header('Location: ctys.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'');
         }
         else
         {
            header('Location: regsubtema.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'');
         }





mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
