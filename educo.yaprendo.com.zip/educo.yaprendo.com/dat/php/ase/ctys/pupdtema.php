<?php

include '../../../cdb/db.php';

$Idusu = $_REQUEST['Idusu'];
$Iddom = $_REQUEST['Iddom'];
$Idcat = $_REQUEST['Idcat'];
$Idcur = $_REQUEST['Idcur'];
$Idtem = $_REQUEST['Idtem'];
$tem = $_REQUEST['tem'];
$des = $_REQUEST['des'];
$ord = $_REQUEST['ord'];




$update_value ="UPDATE Temas SET Tema='".$tem."', Descrip='".$des."', Orden='".$ord."' WHERE Idtem='".$Idtem."' ";
$retry_value = mysqli_query($db_connection,$update_value);


   if($retry_value)
         {
            header('Location: ctys.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'');
         }
         else
         {
            header('Location: updtema.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'');
         }


mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
