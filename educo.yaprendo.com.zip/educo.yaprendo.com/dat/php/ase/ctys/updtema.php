<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Asesores</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />



<?php
include '../../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Asesores</span></h1>
				<h3>Actualiza el Tema</h3>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/ctys/ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				
				<div id="splash">
				<img src="../../../../dat/ima/tema.png" alt="" width="300" height="300" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/ctys/ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>				
						

					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	
	
	<h3>Categoria</h3>

<ul>

<li>
<?php
include '../../../cdb/db.php';
$Idusu = $_GET['Idusu'];
$Iddom = $_GET['Iddom'];
$Idcat = $_GET['Idcat'];
$resultado2=mysqli_query($db_connection, "SELECT Idcat, Categoria FROM Categorias WHERE  Iddom = '".$Iddom."' && Idcat = '".$Idcat."' && Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Categoria=$row2[Categoria];
   $Idcat=$row2[Idcat];

?> 


	<li><a style="color:green;" ><?php echo $Categoria; ?> </a></li>
 

 
<?php

      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
	
				<h3>Curso</h3>

<ul>

<li>
<?php
include '../../../cdb/db.php';
$Idusu = $_GET['Idusu'];
$Iddom = $_GET['Iddom'];
$Idcat = $_GET['Idcat'];
$Idcur = $_GET['Idcur'];
$resultado2=mysqli_query($db_connection, "SELECT Idcur, Curso FROM Cursos WHERE  Idcat = '".$Idcat."' && Estado=1 && Idusu = '".$Idusu."' && Idcur = '".$Idcur."' ORDER BY Idcur  ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Curso=$row2[Curso];
   $Idcur=$row2[Idcur];

?> 


	<li><a style="color:green;" ><?php echo $Curso; ?> </a></li>
 

 
<?php

      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
			<h3>Temas</h3>
						
<ul>

				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = $_GET['Idusu'];
$Iddom = $_GET['Iddom'];
$Idcat = $_GET['Idcat'];
$Idcur = $_GET['Idcur'];
$Idtem = $_GET['Idtem'];
$resultado4=mysqli_query($db_connection, "SELECT Idtem, Tema, Descrip, Orden FROM Temas WHERE  Idtem = '".$Idtem."'  ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
	  $Idtem=$row4[Idtem];  
          $Tema=$row4[Tema];
          $Descrip=$row4[Descrip];
          $Orden=$row4[Orden];


?> 

 <li><a style="color:green;"
 ><?php echo $Orden; ?>.-<?php echo $Tema; ?></a></li>
 <li><a style="color:green;"><?php echo $Descrip; ?></a></li>
<?php

      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>
</li>

</ul>
				
						
						<h3>Actualiza el Tema</h3>
						<ul>
<li> 



<p>
<form action="pupdtema.php" method="POST">

  <input type="hidden" name="Idusu" value="<?php echo $_GET['Idusu']; ?>"> 
  <input type="hidden" name="Iddom" value="<?php echo $_GET['Iddom']; ?>">
  <input type="hidden" name="Idcat" value="<?php echo $_GET['Idcat']; ?>"> 
  <input type="hidden" name="Idcur" value="<?php echo $_GET['Idcur']; ?>">
  <input type="hidden" name="Idtem" value="<?php echo $_GET['Idtem']; ?>">
            
<div>
                    <div>
                        <input type="text" name="tem" size="65" class="form-control" class="form-input"  value="<?php echo $Tema; ?>"   required>
                    </div>
        
                        
                    
                </div>
                <div>
                    <div>
                        <textarea  name="des" rows="20"  cols="65" ><?php echo $Descrip; ?></textarea>
                    </div>
                </div>
<div>
                    <div>
                        <input type="text" name="ord" class="form-control"  class="form-input" value="<?php echo $Orden; ?>"  required>
                    </div>
                </div>
         
                <div>
                    <div>
                        <button type="submit">Actualiza</button>
                                   </div>
                </div>
            </form>





</li>
						</ul>
					
									
					
					
<!-- termina aqui -->				
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para la educación altruista</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

	
</html>


