<?php

include '../../../cdb/db.php';

$Idusu = utf8_decode($_REQUEST['Idusu']);
$Iddom = utf8_decode($_REQUEST['Iddom']);
$Idcat = utf8_decode($_REQUEST['Idcat']);
$Idcur = utf8_decode($_REQUEST['Idcur']);


$tem = $_REQUEST['tem'];
$des = $_REQUEST['des'];
$ord = $_REQUEST['ord'];
$est = 1;


date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$insert_value ="INSERT INTO Temas (Tema, Descrip, Orden, Estado, Idcur ) VALUES ( '".$tem."' ,  '".$des."', '".$ord."', '".$est."', '".$Idcur."')";
$retry_value = mysqli_query($db_connection,$insert_value);



if($retry_value)
         {
           header('Location: ctys.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'');
         }
         else
         {
            header('Location: regtema.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'');
         }

mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
