<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head><meta charset="utf-8">
		<title>Asesores</title>
		
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include '../../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Asesores</span></h1>
				<p>Actualiza subtemas</p>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/ctys/ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsub; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				
				<div id="splash">
					<img src="../../../../dat/ima/subte.png" alt="" width="300" height="300" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/ctys/ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsub; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>				
						

					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	
	<h3>Categoria</h3>

<ul>

<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$resultado2=mysqli_query($db_connection, "SELECT Categoria FROM Categorias WHERE  Iddom = '".$Iddom."' && Idcat = '".$Idcat."' && Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Categoria=$row2[Categoria];
   

?> 


	<li><a style="color:green;" ><?php echo $Categoria; ?> </a></li>
 

 
<?php

      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
	
				<h3>Curso</h3>

<ul>

<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$resultado3=mysqli_query($db_connection, "SELECT Curso FROM Cursos WHERE  Idcat = '".$Idcat."' && Estado=1 && Idusu = '".$Idusu."' && Idcur = '".$Idcur."' ORDER BY Idcur  ");

if (mysqli_num_rows($resultado3)>0)
{			  
      while ($row3 =mysqli_fetch_array($resultado3)) 
	  {
	  $Curso=$row3[Curso];
   

?> 


	<li><a style="color:green;" ><?php echo $Curso; ?> </a></li>
 

 
<?php

      }
}
mysqli_free_result($resultado3);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
			<h3>Temas</h3>
						
<ul>

				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$resultado4=mysqli_query($db_connection, "SELECT Tema, Descrip, Orden FROM Temas WHERE  Idtem = '".$Idtem."'  ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
	  
          $Tema=$row4[Tema];
         
          $Orden1=$row4[Orden];


?> 

 <li><a style="color:green;"
 ><?php echo $Orden1; ?>.-<?php echo $Tema; ?></a></li>

<?php

      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>
</li>

</ul>
				
				
			<h3>Subtemas</h3>
						
<ul>

				   
<li>
<?php
include '../../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);
$resultado5=mysqli_query($db_connection, "SELECT Subtema, Descrip, Orden FROM Subtemas WHERE  Idsub = '".$Idsub."'  ");

if (mysqli_num_rows($resultado5)>0)
{			  
      while ($row5 =mysqli_fetch_array($resultado5)) 
	  {
	  
          $Subtema=$row5[Subtema];
         $Descrip=$row5[Descrip];
         
          $Orden2=$row5[Orden];


?> 

 <li><a style="color:green;"
 ><?php echo $Orden2; ?>.-<?php echo $Subtema; ?></a></li>

<?php

      }
}
mysqli_free_result($resultado5);
mysqli_close($db_connection);
 ?>
</li>

</ul>
				

		
<h3>Actualiza el Subtema</h3>
<ul>
<li> 



<p>
<form action="pupdsubtema.php" method="POST">
            
<div>
                    <div>

  <input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>"> 
  <input type="hidden" name="Iddom" value="<?php echo utf8_decode($_GET['Iddom']); ?>">
  <input type="hidden" name="Idcat" value="<?php echo utf8_decode($_GET['Idcat']); ?>"> 
  <input type="hidden" name="Idcur" value="<?php echo utf8_decode($_GET['Idcur']); ?>">
  <input type="hidden" name="Idtem" value="<?php echo utf8_decode($_GET['Idtem']); ?>">
 <input type="hidden" name="Idsub" value="<?php echo utf8_decode($_GET['Idsub']); ?>">
 


 <input type="text" name="sub" size="65" class="form-control" class="form-input"   value="<?php echo $Subtema; ?>" required>
                    </div>
        
                        
                    
                </div>
                <div>
                    <div>
                        <textarea class="form-control" name="des" rows="20"  cols="65"  ><?php echo $Descrip; ?> </textarea>
                    </div>
                </div>
<div>
                    <div>
                        <input type="text" name="ord" class="form-control"  class="form-input"
                          value="<?php echo $Orden2; ?>"   required>
                    </div>
                </div>
         
                <div>
                    <div>
                        <button type="submit">Actualiza</button>
                                   </div>
                </div>
            </form>





</li>
						</ul>
						
					
					
<!-- termina aqui -->				
<!-- End Sidebar -->				
					





	
					
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
	<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

	
</html>



