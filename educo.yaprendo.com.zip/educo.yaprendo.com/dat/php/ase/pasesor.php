<?php

include '../../cdb/db.php';

$nom = $_REQUEST['nom'];
$ape = $_REQUEST['ape'];
$mov = $_REQUEST['mov'];
$cor = $_REQUEST['cor'];
$pas = $_REQUEST['pas'];
$des = $_REQUEST['des'];
$men=  $_REQUEST['men'];
$tip= utf8_decode($_REQUEST['tip']);
$Iddom= utf8_decode($_REQUEST['Iddom']);

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$resultado=mysqli_query($db_connection, "SELECT Idusu FROM Usuarios WHERE Correo = '".$cor."' ");
 

if (mysqli_num_rows($resultado)>0)
{
header('Location: ../../../index.php?nom='.$nom.'& mov='.$mov.'&cor='.$cor.'');
 } else {


$insert_value = "INSERT INTO Usuarios (Nombres, Apellidos, Correo, Movil, Pass, Mensaje, Descrip, Estado, Tipo, Idrus, Iddom) VALUES ('".$nom."',  '".$ape."',  '".$cor."',  '".$mov."',  '".$pas."', '".$men."',  '".$des."', 0,'".$tip."',0, 1)";

$retry_value = mysqli_query($db_connection,$insert_value);


$cuerpo='Nombre: '. $nom.'  Movil: '.$mov.'  Correo: '.$cor.'  Comentario: '.$men;

mail('soporte@yaprendo.com','Un Asesor dale seguimiento->',$cuerpo,'Equipo El Taller');

$resultado=mysqli_query($db_connection, "SELECT Idusu FROM Usuarios  WHERE Nombres = '".$nom."' ");


while ($row =mysqli_fetch_array($resultado)) {
   	 $Idusu=$row[Idusu];
   }



header('Location: asesores.php?Iddom='.$Iddom.'&Idusu='.$Idusu.'');

}

mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
