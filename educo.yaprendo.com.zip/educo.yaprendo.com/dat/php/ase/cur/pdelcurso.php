<?php

include '../../../cdb/db.php';

$Idusu = utf8_decode($_REQUEST['Idusu']);
$Iddom = utf8_decode($_REQUEST['Iddom']);
$Idcat = utf8_decode($_REQUEST['Idcat']);
$Idcur = utf8_decode($_REQUEST['Idcur']);


$Idusux = 0;

$update_value ="UPDATE Cursos SET Idusu='".$Idusux."' WHERE Idcur='".$Idcur."' ";



	$retry_value = mysqli_query($db_connection,$update_value);



header('Location: curso.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'');



mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
