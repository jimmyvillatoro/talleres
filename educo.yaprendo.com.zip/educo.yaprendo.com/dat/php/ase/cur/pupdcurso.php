<?php

include '../../../cdb/db.php';

$Idusu = utf8_decode($_REQUEST['Idusu']);
$Iddom = utf8_decode($_REQUEST['Iddom']);
$Idcat = utf8_decode($_REQUEST['Idcat']);
$Idcur = utf8_decode($_REQUEST['Idcur']);


$cur = $_REQUEST['cur'];
$des = $_REQUEST['des'];
$pre = $_REQUEST['pre'];
$cos = $_REQUEST['cos'];
$pro = $_REQUEST['pro'];
$tip = $_REQUEST['tip'];

$update_value ="UPDATE Cursos SET Curso='".$cur."', Descrip='".$des."', Costo='".$cos."', Precio='".$pre."', Promo='".$pro."', Tipo='".$tip."' WHERE Idcur='".$Idcur."' ";



	$retry_value = mysqli_query($db_connection,$update_value);



header('Location: curso.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'');



mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
