<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Asesores</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include '../../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Asesores</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/cur/curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				
				<div id="splash">
					<img src="../../../ima/exito.jpg" alt="" width="300" height="200" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/cur/curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>				
						

					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	
	
<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>

						<h3>Registrar</h3>
						<ul>
<li> 



        <p>
            <form action="pcurso.php" method="POST">
            
			  
 <div>
<div >Categoria:
<SELECT NAME="selCombo1" SIZE=1 > 			  
			  
<?php
	
include '../../../cdb/db.php';

$Iddom = utf8_decode($_GET['Iddom']);

$resultado1=mysqli_query($db_connection, "SELECT Idcat, Categoria FROM Categorias WHERE Estado=1 && Iddom=1 ORDER BY Orden ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Idcat=$row1[Idcat];
	  $Categoria=$row1[Categoria];
	  
	  
?> 

 
<OPTION selected="selected" VALUE="<?php echo $Idcat; ?>"><?php echo $Categoria; ?>  </OPTION>
<?php
      }
}

mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>
		  
</SELECT>  




               
                    <div>
<input type="hidden" name="Idusu" value="<?php echo $Idusu ?>">
<input type="hidden" name="Iddom" value="<?php echo $Iddom ?>">

  <input type="text" name="cur" size="70" class="form-control" placeholder="Curso" class="form-input" required>
                    </div>
        
       
                </div>
                <div>
                    <div>
                        <textarea class="form-control" name="des" rows="20"cols="75" placeholder="Descripcion"></textarea>
                    </div>
                </div>
 <div>                 
 <input type="text" name="tip" class="form-control" placeholder="Tipo = 1 gratis 2 pagado " class="form-input"                           required>    
      </div>  
         
 <div>                 
 <input type="text" name="cos" class="form-control" placeholder="Costo" class="form-input"                           required>    
      </div>  
         
 <div>                 
 <input type="text" name="pre" class="form-control" placeholder="Precio" class="form-input"                           required>    
      </div>  
         

 <div>                 
 <input type="text" name="pro" class="form-control" placeholder="Promoción" class="form-input"                           required>    
      </div>  
         
                <div>
                    <div>
                        <button type="submit">Alta</button>
                                   </div>
                </div>
            </form>





</li>
						</ul>
					
					
<!-- termina aqui -->				
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para la educación altruista</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

	
</html>