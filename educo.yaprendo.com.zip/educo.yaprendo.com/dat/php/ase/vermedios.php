<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Asesores</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include '../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Asesores</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/vercurso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				
				<div id="splash">
					<img src="../../ima/splash.jpg" alt="" width="960" height="400" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/vercurso.phpIdusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?> " title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			
			</ul>				
						

	
		<!-- End Sidebar -->				
					</div>			
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	
	
<p>Ver medios del tema</p>


<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>


<?php
include '../../cdb/db.php';
$Idtem = utf8_decode($_GET['Idtem']);
$Tabla ="Temas";
$result4=mysqli_query($db_connection, "SELECT Medio, Url FROM Medios WHERE  Idtab = '".$Idtem."' && Tabla='".$Tabla."'");

if (mysqli_num_rows($result4)>0) 
while ($row4 =mysqli_fetch_array($result4)) 
	  {

$med4=$row4[Medio];
$url4=$row4[Url];

if($med4=="imagen"){
 ?>

<img src="<?php echo $url4; ?>" alt="" width="600" height="600" class="round" />

<?php }
if($med4=="video"){
  ?>

<video src="<?php echo $url4; ?>" width="300" height="600" controls>

<?php }
if($med4=="audio"){
  ?>

<video src="<?php echo $url4; ?>" width="300" height="100" controls>

<?php }
if($med4=="documento"){
  ?>

<a href="<?php echo $url4; ?>"  title="<?php echo $url4; ?>" class="round active"><?php echo $url4; ?></a>

<?php 
}
      }//medios
mysqli_free_result($result4);

mysqli_close($db_connection);
 ?>



					
<!-- termina aqui -->				
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para la educación altruista</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

	
</html>