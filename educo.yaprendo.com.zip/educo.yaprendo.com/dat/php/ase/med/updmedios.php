<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Asesores</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include '../../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$Idsub = utf8_decode($_GET['Idsub']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Asesores</span></h1>
				<p>Actualiza medio al curso</p>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/med/medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsub; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				
				<div id="splash">
					<img src="../../../ima/exito.jpg" alt="" width="300" height="200" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/med/medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>&Idsub=<?php echo $Idsub; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>				
						

					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	
	


	
<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>


<div id="wrapper2" class="round">					
<div id="sidebar" class="round">					
<h3>Categoria</h3>
<ul>
<li>
<?php
include '../../../cdb/db.php';
$Idcat = utf8_decode($_GET['Idcat']);
$resultado2=mysqli_query($db_connection, "SELECT Categoria FROM Categorias WHERE  Idcat = '".$Idcat."' ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
	  $Categoria=$row2[Categoria];
?>
	<li><a style="color:green;"><?php echo $Categoria; ?> </a></li>

<?php
      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>
	

<h3>Curso</h3>	
<ul>
<li>
<?php
include '../../../cdb/db.php';
$Idcur = utf8_decode($_GET['Idcur']);
$resultado4=mysqli_query($db_connection, "SELECT Curso FROM Cursos WHERE  Idcur= '".$Idcur."' ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
	  $Curso=$row4[Curso];
?> 

<li><a  style="color:green;"><?php echo $Curso; ?></a></li>

<?php
      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>
</li>

</ul>
					
<?php
include '../../../cdb/db.php';
$Idmed = utf8_decode($_GET['Idmed']);
$resultado5=mysqli_query($db_connection, "SELECT Medio, Descrip, Orden, Url FROM Medios WHERE  Idmed= '".$Idmed."' ");

if (mysqli_num_rows($resultado5)>0)
{			  
      while ($row5 =mysqli_fetch_array($resultado5)) 
	  {
$med=$row5[Medio];
$des=$row5[Descrip];
$ord=$row5[Orden];
$url=$row5[Url];
      }
}
mysqli_free_result($resultado5);
mysqli_close($db_connection);
 ?>

<h3>Actualiza el Medio</h3>
<ul>
<li> 
<?php

if($med=="imagen" || $med=="Imagen"){
 ?>
<li align="center">
<img src="<?php echo $url; ?>" alt="" width="300" height="300" class="round" />
</li>
<?php }
if($med=="video" || $med=="Video" || $med=="Vídeo"){
  ?>
<li align="center">
<video src="<?php echo $url; ?>" width="300" height="300" controls>
</li>		
<?php }
if($med=="audio" || $med=="Audio"){
  ?>
<li align="center">
<video src="<?php echo $url; ?>" width="300" height="300" controls>
</li>		
<?php }
if($med=="documento" || $med=="Documento"){
  ?>
<li align="center">
<a href="<?php echo $url; ?>"  title="<?php echo $url; ?>" class="round active"><?php echo $url; ?></a>
</li>		
<?php



}
  ?>
</li>		

<form action="pupdmedios.php" method="POST">

          
<div>
<div>

  <input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>"> 
  <input type="hidden" name="Iddom" value="<?php echo utf8_decode($_GET['Iddom']); ?>">
  <input type="hidden" name="Idcat" value="<?php echo utf8_decode($_GET['Idcat']); ?>"> 
  <input type="hidden" name="Idcur" value="<?php echo utf8_decode($_GET['Idcur']); ?>">
  <input type="hidden" name="Idmed" value="<?php echo utf8_decode($_GET['Idmed']); ?>">
  <input type="hidden" name="Idtem" value="<?php echo utf8_decode($_GET['Idtem']); ?>">
  <input type="hidden" name="Idsub" value="<?php echo utf8_decode($_GET['Idsub']); ?>">


<select name="med">
<option value="<?php echo $med; ?>"><?php echo $med=ucwords($med); ?></option>
<option value="imagen">Imagen</option>
<option value="video">Vídeo</option>
<option value="audio">Audio</option>
<option value="documento">Documento</option>
</select>

 </div>  
 </div>
                

<div>
<div>

<textarea class="form-control" name="des" rows="20"  cols="65"  ><?php echo $des; ?> </textarea>
</div>
</div>


<div>
<div>
<input type="text" name="url" size="65" class="form-control" class="form-input" value="<?php echo $url; ?>" required>

</div>
</div>

<div>
<div>
<input type="text" name="ord" class="form-control" class="form-input" value="<?php echo $ord; ?>" required>
</div>  
</div>

<div>
<div>
<button type="submit">Actualiza</button>
</div>
</div>
</form>






</li>
						</ul>	
					
					
<!-- termina aqui -->
	</div>
		</div>
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para la educación altruista</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

	
</html>



