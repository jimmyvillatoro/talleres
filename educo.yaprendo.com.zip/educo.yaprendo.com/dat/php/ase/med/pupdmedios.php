<?php

include '../../../cdb/db.php';

$Idusu = utf8_decode($_REQUEST['Idusu']);
$Iddom = utf8_decode($_REQUEST['Iddom']);
$Idcat = utf8_decode($_REQUEST['Idcat']);
$Idcur = utf8_decode($_REQUEST['Idcur']);
$Idmed = utf8_decode($_REQUEST['Idmed']);
$Idtem = utf8_decode($_REQUEST['Idtem']);
$Idsub = utf8_decode($_REQUEST['Idsub']);

$med = $_REQUEST['med'];
$des = $_REQUEST['des'];
$ord = $_REQUEST['ord'];
$url = $_REQUEST['url'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());

$update_value ="UPDATE Medios SET Medio='".$med."', Descrip='".$des."', Orden='".$ord."' , Url='".$url."' WHERE Idmed='".$Idmed."' ";

$retry_value = mysqli_query($db_connection,$update_value);



header('Location: medios.php?Idusu='.$Idusu.'&Iddom='.$Iddom.'&Idcat='.$Idcat.'&Idcur='.$Idcur.'&Idtem='.$Idtem.'&Idsub='.$Idsub.'');


mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
