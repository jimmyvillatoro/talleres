<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Asesores</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include '../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$Idcat = utf8_decode($_GET['Idcat']);
$Idcur = utf8_decode($_GET['Idcur']);
$Idtem = utf8_decode($_GET['Idtem']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Asesores</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/cur/curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				
				<div id="splash">
					<img src="../../ima/splash.jpg" alt="" width="960" height="400" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/cur/curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>&Idtem=<?php echo $Idtem; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			
			</ul>				
						

	
		<!-- End Sidebar -->				
					</div>			
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	
	
<ul>
<li align="center">
<a > <img src="../../ima/texto.png" alt="" width="200" height="200" class="round" /> </a></li>
</ul>
					
<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>


<?php
include '../../cdb/db.php';

$Idcur = utf8_decode($_GET['Idcur']);
$result=mysqli_query($db_connection, "SELECT Curso, Descrip FROM Cursos WHERE  Idcur = '".$Idcur."' && Estado=1  ");

if (mysqli_num_rows($result)>0)
while ($rowx =mysqli_fetch_array($result)) 
	  {
	$Cursox=$rowx[Curso];
 $Descripx=$rowx[Descrip];

?> 
<h3>Curso: <a style="color:black;" ><?php echo $Cursox; ?></a></h3>

<br>
<a style="color:orange;" ><?php echo $Descripx; ?></a>
<br>
<?php

$Idcur = utf8_decode($_GET['Idcur']);
$Tabla ="Cursos";
$result3=mysqli_query($db_connection, "SELECT Medio, Url FROM Medios WHERE  Idtab = '".$Idcur."' && Tabla='".$Tabla."'");

if (mysqli_num_rows($result3)>0) 
while ($row3 =mysqli_fetch_array($result3)) 
	  {

$med3=$row3[Medio];
$url3=$row3[Url];

if($med3=="imagen"){
 ?>

<img src="<?php echo $url3; ?>" alt="" width="200" height="200" class="round" />

<?php }
if($med3=="video"){
  ?>

<video src="<?php echo $url3; ?>" width="300" height="300" controls>

<?php }
if($med3=="audio"){
  ?>

<video src="<?php echo $url3; ?>" width="300" height="100" controls>

<?php }
if($med3=="documento"){
  ?>

<a href="<?php echo $url3; ?>"  title="<?php echo $url3; ?>" class="round active"><?php echo $url3; ?></a>

<?php }


      }//medios
mysqli_free_result($result3);
 
      }//cursos
mysqli_free_result($result);
mysqli_close($db_connection);
 ?>



<?php
include '../../cdb/db.php';

$Idcur = utf8_decode($_GET['Idcur']);

$result2=mysqli_query($db_connection, "SELECT Idtem, Tema, Descrip, Orden from Temas  WHERE Idcur='".$Idcur."' and Estado=1 ORDER BY Orden  ");

if (mysqli_num_rows($result2)>0)
while ($row2 =mysqli_fetch_array($result2)) 
	  {

$Tema2=$row2[Tema];
$Idtem2=$row2[Idtem];
$Descrip2=$row2[Descrip];
$Orden2=$row2[Orden];

?> 
<br>
<h3>
<a style="color:green;"><?php echo $Orden2; ?>.-<?php echo $Tema2; ?></a>
</h3>
<br>
<a style="color:orange;" ><?php echo $Descrip2; ?></a>
<br>
<br>
<a href="vermedios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idtem=<?php echo $Idtem2; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>" >ver medio</a>  <a href="versubtemas.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idtem=<?php echo $Idtem2; ?>&Idcat=<?php echo $Idcat; ?>&Idcur=<?php echo $Idcur; ?>" >ver subtema</a>
<br>
<br>



<?php
}//temas

mysqli_free_result($result2);

mysqli_close($db_connection);
 ?>


					
<!-- termina aqui -->	

			<!-- End Content -->
					</div>		
					
		
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para la educación altruista</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

	
</html>