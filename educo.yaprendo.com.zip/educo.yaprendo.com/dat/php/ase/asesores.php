<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Asesores</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include '../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Asesores</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				
				<div id="splash">
					<img src="../../ima/splash.jpg" alt="" width="960" height="400" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
			<li><a href="index.html">Inicio</a></li>
			<li><a href="#">Acerca de</a></li>
    <li><a href="#">Contactanos</a></li>
			<li><a href="#">Soporte</a></li>
			
			</ul>				
						
						<h3>Asesores</h3>
						<ul>
						   <li>Registro</li>
						   <li>Control de Alumnos</li>
						   <li>Certificados</li>
						   <li>Finanzas</li>
						</ul>

						<h3>Alumnos</h3>
						<ul>
		   <li>Registro</li>
           <li>Seguimiento de cursos</li>
           <li>Control de Diplomas</li>
           <li>Inscripción a cursos</li>
						</ul>

       <h3>Administración</h3>
						<ul>
			<li>Acceso al Portal</li>
    <li>Sistema</li>
    <li>Asesores</li>
    <li>Alumnos</li>
    <li>Cursos</li>
    <li>Certificados</li>
						</ul>

 <h3>Soporte</h3>
						<ul>
			<li>Ticket</li>
    <li>Llamar</li>
    <li>Correo</li>
    <li>Mensaje</li>
    <li>Chat</li>
						</ul>
					
					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">
					

	
<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>


<div id="wrapper2" class="round">					
<div id="sidebar" class="round">					
<h3>Tu Lista de Cursos</h3>					
<ul>
<?php
include '../../cdb/db.php';
$Idusu = utf8_decode($_GET['Idusu']);
$resultado1=mysqli_query($db_connection, "SELECT Idcur, Curso FROM Cursos WHERE  Idusu = '".$Idusu."' && Estado=1 ORDER BY Idcur  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
	  $Curso=$row1[Curso];
	  $Idcurx=$row1[Idcur];
?> 
	<li><a href="repcurso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>&Idcur=<?php echo $Idcurx; ?>"> <img src="../../ima/pdf.png" alt="" width="50" height="40"  class="round"/> <?php echo $Curso; ?> </a></li>
 
<?php
      }
}
mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>					
</ul>


<h3>Control de Cursos</h3>					
<ul>		

<li align="center">
<a href="cur/curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> <img src="../../ima/curso.jpg" alt="" width="200" height="150"  class="round" /> </a></li>
<li align="center">
<a href="cur/curso.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">Administrar mis cursos</a></li>		
</ul>

<h3>Control de contenido</h3>
<ul>	

<li align="center">
<a href="ctys/ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> <img src="../../ima/orga.jpg" alt="" width="200" height="150"  class="round" /> </a></li>


<li align="center">
<a href="ctys/ctys.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">Administrar el contenido</a></li>
</ul>
	
<h3>Control de Medios</h3>					
<ul>

<li align="center">
<a href="med/medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> <img src="../../ima/medios.jpg" alt="" width="200" height="150"  class="round" /> </a></li>


<li align="center"><a href="med/medios.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">Administrar los medios</a></li>					
</ul>


<h3>Control de Alumnos</h3>					
<ul>
<li align="center">
<a href="alu/alum.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> <img src="../../ima/users.png" alt="" width="200" height="150"  class="round" /> </a></li>

<li align="center"><a href="alu/alum.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">Administrar los alumnos</a></li>					
</ul>


<h3>Control de tu perfil</h3>					
<ul>
<li align="center">
<a href="perfil.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"> <img src="../../ima/user.jpeg" alt="" width="200" height="150"  class="round" /> </a></li>
<li align="center"><a href="perfil.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">Administrar tu perfil</a></li>					
</ul>

<h3>Información</h3>
						
<ul>
 
<li>Los datos están seguros en la nube, pero puedes tener instalada nuestra plataforma en tu sitio web.</li>
						<img src="../../ima/datos.jpg" alt="" width="300" height="200" class="round" />     
<li>Nosotros hicimos está plataforma pensando en un bien común para la humanidad.</li>
						
</ul>


					
					
<!-- End Sidebar -->				
					
</div>




    </div>

	
					
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
	<div id="footer">
			
<p>copyright &copy; 2020 Talleres <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para app</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

	
</html>
