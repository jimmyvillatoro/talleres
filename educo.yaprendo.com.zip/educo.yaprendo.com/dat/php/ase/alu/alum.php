<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Asesores</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include '../../../cdb/db.php';
$Iddom = utf8_decode($_GET['Iddom']);
$Idusu = utf8_decode($_GET['Idusu']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM Usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $nom=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Asesores</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/asesores.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>
					</div>
				
				<div id="splash">
					<img src="../../../ima/exito.jpg" alt="" width="960" height="400" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="https://educo.yaprendo.com/index.html" title="" class="round active">Inicio</a></li>
<li><a href="https://educo.yaprendo.com/dat/php/ase/asesores.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>" title="" class="round">Atrás</a></li>
<li><a href="https://yaprendo.com/edu/" title="" class="round">Edu</a></li>
<li><a href="https://educo.yaprendo.com/contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="https://educo.yaprendo.com/soporte.php" title="" class="round">Soporte</a></li>
			</ul>				
						

					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	
	
					
<p>Asesor:<a style="color:orange;"> <?php echo $nom; ?> </a></p>


<div id="wrapper2" class="round">					
<div id="sidebar" class="round">					
<h3>Alumnos</h3>
						
					
<ul>
<li>Selecciona el Alumno</li>
<li>
<?php


include '../../../cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);
$Iddom = utf8_decode($_GET['Iddom']);
$Idcat = utf8_decode($_GET['Idcat']);

$resultado2=mysqli_query($db_connection, "SELECT Nombres, Apellidos, Correo, Movil FROM Usuarios  WHERE Iddom = '".$Iddom."' && Tipo = 1");

while ($row2 =mysqli_fetch_array($resultado2)) {
   	 $nom=$row2[Nombres];
   	 $ape=$row2[Apellidos];
   	 $cor=$row2[Correo];
   	 $mov=$row2[Movil];

?> 


<li><a style="color:black;" href="alum.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"><?php echo $nom; ?> <?php echo $ape; ?></a></li>
<li><a style="color:black;" href="alum.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>"><?php echo $cor; ?>  </a></li>
 <li><a style="color:black;" href="alum.php?Idusu=<?php echo $Idusu; ?>&Iddom=<?php echo $Iddom; ?>">  <?php echo $mov; ?></a></li>
 

<?php

      }

mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>
</li>					
</ul>


						
<h3>Administra alumnos</h3>
						
					
<ul>
<li>Alumno</li>
<li>		
</ul>

				
							
						
<h3>Información</h3>
						
<ul>
<li>En esta área creas los temas y subtemas del curso seleccionado</li>
<li>Crea tu curso a la medida de tú capacidad</li>
<li>Comunicate con nosotros.</li>
</ul>
				
					
<!-- termina aqui -->	

					
<!-- End Sidebar -->				
					
</div>




    </div>

				<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web para la educación altruista</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">Jimmy Villatoro</a>.</div></body>
	

	
</html>


